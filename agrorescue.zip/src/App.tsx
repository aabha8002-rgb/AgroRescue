/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TopHeader } from './components/TopHeader';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { AIFreshnessScanner } from './components/AIFreshnessScanner';
import { HarvestBatchManager } from './components/HarvestBatchManager';
import { StorageCompatibilityChecker } from './components/StorageCompatibilityChecker';
import { SellOrStoreCalculator } from './components/SellOrStoreCalculator';
import { TransportOptimizer } from './components/TransportOptimizer';
import { AIRescueAdvisor } from './components/AIRescueAdvisor';
import { FarmerProfileSettings } from './components/FarmerProfileSettings';

import {
  HarvestBatch,
  ScanResult,
  FarmerProfile,
  Language,
} from './types';
import {
  INITIAL_BATCHES,
  INITIAL_RECENT_SCANS,
  INITIAL_FARMER_PROFILE,
} from './data/initialBatches';

export default function App() {
  // Persistent language state
  const [currentLanguage, setCurrentLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('agrorescue_lang');
    return (saved as Language) || 'en';
  });

  // Persistent farmer profile
  const [farmerProfile, setFarmerProfile] = useState<FarmerProfile>(() => {
    const saved = localStorage.getItem('agrorescue_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_FARMER_PROFILE;
  });

  // Persistent batches
  const [batches, setBatches] = useState<HarvestBatch[]>(() => {
    const saved = localStorage.getItem('agrorescue_batches');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_BATCHES;
  });

  // Persistent recent scans
  const [recentScans, setRecentScans] = useState<ScanResult[]>(() => {
    const saved = localStorage.getItem('agrorescue_scans');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return INITIAL_RECENT_SCANS;
  });

  const [activePage, setActivePage] = useState<string>('dashboard');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [selectedBatchForInspection, setSelectedBatchForInspection] = useState<HarvestBatch | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('agrorescue_lang', currentLanguage);
  }, [currentLanguage]);

  useEffect(() => {
    localStorage.setItem('agrorescue_profile', JSON.stringify(farmerProfile));
  }, [farmerProfile]);

  useEffect(() => {
    localStorage.setItem('agrorescue_batches', JSON.stringify(batches));
  }, [batches]);

  useEffect(() => {
    localStorage.setItem('agrorescue_scans', JSON.stringify(recentScans));
  }, [recentScans]);

  const handleLanguageChange = (lang: Language) => {
    setCurrentLanguage(lang);
    setFarmerProfile((prev) => ({ ...prev, selectedLanguage: lang }));
  };

  const handleAddBatch = (batch: HarvestBatch) => {
    setBatches((prev) => [batch, ...prev]);
  };

  const handleUpdateBatch = (updated: HarvestBatch) => {
    setBatches((prev) => prev.map((b) => (b.id === updated.id ? updated : b)));
  };

  const handleDeleteBatch = (id: string) => {
    setBatches((prev) => prev.filter((b) => b.id !== id));
  };

  const handleScanCompleted = (result: ScanResult) => {
    setRecentScans((prev) => [result, ...prev.slice(0, 5)]);
  };

  const handleSaveAsBatchFromScanner = (batchData: Partial<HarvestBatch>) => {
    const newId = `batch-${Date.now()}`;
    const code = `NSK-${batchData.crop?.substring(0, 3).toUpperCase() || 'TOM'}-${Math.floor(100 + Math.random() * 900)}`;

    const fullBatch: HarvestBatch = {
      id: newId,
      batchCode: code,
      crop: batchData.crop || 'Tomato',
      variety: batchData.variety || 'Inspection Batch',
      harvestDate: batchData.harvestDate || new Date().toISOString().split('T')[0],
      quantityKg: batchData.quantityKg || 2000,
      initialQuantityKg: batchData.quantityKg || 2000,
      currentFreshnessScore: batchData.currentFreshnessScore ?? 78,
      grade: batchData.grade || 'Grade B+',
      riskLevel: batchData.riskLevel || 'Warning',
      storageType: batchData.storageType || 'Ventilated Crates',
      location: batchData.location || 'Sorting Table A',
      estimatedShelfLifeAmbientDays: batchData.estimatedShelfLifeAmbientDays ?? 3.5,
      estimatedShelfLifeColdDays: batchData.estimatedShelfLifeColdDays ?? 14,
      estimatedMarketValueInr: batchData.estimatedMarketValueInr ?? 36000,
      notes: batchData.notes || 'Created from AI Scanner inspection',
      imageUrl: batchData.imageUrl,
      isDemoData: false,
      lastInspectedDate: new Date().toISOString().split('T')[0],
    };

    handleAddBatch(fullBatch);
    setActivePage('batches');
  };

  const handleResetDemoData = () => {
    if (confirm('Reset all batches and scans to the demonstration Nashik tomato cluster data?')) {
      setBatches(INITIAL_BATCHES);
      setRecentScans(INITIAL_RECENT_SCANS);
      setFarmerProfile(INITIAL_FARMER_PROFILE);
      localStorage.removeItem('agrorescue_batches');
      localStorage.removeItem('agrorescue_scans');
      localStorage.removeItem('agrorescue_profile');
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9F5] text-stone-900 flex flex-col md:flex-row antialiased selection:bg-emerald-700 selection:text-white">
      {/* Sidebar Navigation (Desktop) & Bottom Navigation (Mobile) */}
      <Navigation
        activePage={activePage}
        onNavigate={(page) => {
          setActivePage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        currentLanguage={currentLanguage}
        isSidebarCollapsed={isSidebarCollapsed}
        onToggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 pb-20 md:pb-8">
        {/* Top Header */}
        <TopHeader
          currentLanguage={currentLanguage}
          onLanguageChange={handleLanguageChange}
          farmerProfile={farmerProfile}
          onOpenVoiceModal={() => {
            setActivePage('voice-advisor');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onNavigate={(page) => {
            setActivePage(page);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          activePage={activePage}
        />

        {/* Page Content Container */}
        <main className="flex-1 px-4 md:px-8 py-6 max-w-7xl w-full mx-auto">
          {activePage === 'dashboard' && (
            <Dashboard
              batches={batches}
              recentScans={recentScans}
              currentLanguage={currentLanguage}
              onNavigate={(page) => {
                setActivePage(page);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onSelectBatchForInspection={(batch) => {
                setSelectedBatchForInspection(batch);
                setActivePage('batches');
              }}
            />
          )}

          {activePage === 'scanner' && (
            <AIFreshnessScanner
              currentLanguage={currentLanguage}
              onSaveAsBatch={handleSaveAsBatchFromScanner}
              onScanCompleted={handleScanCompleted}
            />
          )}

          {activePage === 'batches' && (
            <HarvestBatchManager
              batches={batches}
              currentLanguage={currentLanguage}
              onAddBatch={handleAddBatch}
              onUpdateBatch={handleUpdateBatch}
              onDeleteBatch={handleDeleteBatch}
              selectedBatchForInspection={selectedBatchForInspection}
              onCloseInspectionModal={() => setSelectedBatchForInspection(null)}
            />
          )}

          {activePage === 'storage-checker' && (
            <StorageCompatibilityChecker currentLanguage={currentLanguage} />
          )}

          {activePage === 'sell-store' && (
            <SellOrStoreCalculator currentLanguage={currentLanguage} />
          )}

          {activePage === 'transport' && (
            <TransportOptimizer currentLanguage={currentLanguage} />
          )}

          {activePage === 'voice-advisor' && (
            <AIRescueAdvisor
              currentLanguage={currentLanguage}
              batches={batches}
              autoStartListening={false}
            />
          )}

          {activePage === 'settings' && (
            <FarmerProfileSettings
              profile={farmerProfile}
              currentLanguage={currentLanguage}
              onUpdateProfile={setFarmerProfile}
              onLanguageChange={handleLanguageChange}
              onResetDemoData={handleResetDemoData}
            />
          )}
        </main>
      </div>
    </div>
  );
}
