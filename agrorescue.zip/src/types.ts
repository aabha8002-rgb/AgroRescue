export type Language = 'en' | 'hi' | 'mr';

export type CropType =
  | 'Tomato'
  | 'Onion'
  | 'Potato'
  | 'Capsicum'
  | 'Green Chilli'
  | 'Banana'
  | 'Mango'
  | 'Cauliflower';

export type BatchRiskLevel = 'Stable' | 'Warning' | 'Urgent';

export type BatchGrade = 'Grade A' | 'Grade B+' | 'Grade B' | 'Grade C' | 'Rejected';

export interface DefectItem {
  name: string;
  severity: 'Low' | 'Medium' | 'High';
  description: string;
}

export interface ValueRecoveryOption {
  channel: string;
  estimatedValuePct: string;
  action: string;
}

export interface HarvestBatch {
  id: string;
  batchCode: string;
  crop: CropType;
  variety: string;
  harvestDate: string; // YYYY-MM-DD
  quantityKg: number;
  initialQuantityKg: number;
  currentFreshnessScore: number; // 0 - 100
  grade: BatchGrade;
  riskLevel: BatchRiskLevel;
  storageType: 'Ambient Shed' | 'Ventilated Crates' | 'Cold Storage' | 'On-Field Holding';
  location: string;
  estimatedShelfLifeAmbientDays: number;
  estimatedShelfLifeColdDays: number;
  estimatedMarketValueInr: number;
  notes: string;
  imageUrl?: string;
  isDemoData?: boolean;
  lastInspectedDate: string;
}

export interface ScanResult {
  id: string;
  timestamp: string;
  crop: CropType;
  freshnessScore: number;
  grade: BatchGrade;
  visibleCondition: string;
  defectsIdentified: DefectItem[];
  shelfLifeAmbientDays: number;
  shelfLifeColdStoreDays: number;
  recommendedAction: string;
  riskLevel: BatchRiskLevel;
  valueRecoveryOptions: ValueRecoveryOption[];
  storageTips: string;
  imagePreviewUrl?: string;
  batchCreatedId?: string;
}

export interface CropStorageProfile {
  crop: CropType;
  commonNameHi: string;
  commonNameMr: string;
  optimalTempMinC: number;
  optimalTempMaxC: number;
  optimalHumidityMinRh: number;
  optimalHumidityMaxRh: number;
  chillingInjuryThresholdC: number | null;
  ambientShelfLifeDays: number;
  coldStorageShelfLifeDays: number;
  ethyleneProduction: 'Low' | 'Moderate' | 'High';
  ethyleneSensitivity: 'Low' | 'Moderate' | 'High';
  moistureSensitivity: 'Low' | 'Moderate' | 'High';
  incompatibleCrops: {
    crop: CropType;
    reason: string;
  }[];
  criticalPrecautions: string[];
  missingInfoChecklist: string[];
}

export interface SellOrStoreInputs {
  crop: CropType;
  quantityKg: number;
  todayPricePerKg: number; // ₹/kg
  expectedFuturePricePerKg: number; // ₹/kg
  storageDurationDays: number;
  coldStorageMonthlyRatePerKg: number; // ₹/kg/month or ₹/crate
  handlingAndElectricityInr: number;
  transportToMandiTodayInr: number;
  transportToStorageInr: number;
  transportFromStorageToMandiInr: number;
  expectedSpoilagePercent: number; // 0 - 50%
}

export interface SellOrStoreResult {
  sellTodayNetRevenue: number;
  storeNetRevenue: number;
  netBenefitOfStoring: number;
  breakEvenFuturePricePerKg: number;
  estimatedSpoilageKg: number;
  estimatedStorageCosts: number;
  estimatedTransportTotal: number;
  recommendation: 'SELL_TODAY' | 'STORE_PRODUCE' | 'NEUTRAL';
  reasoning: string;
}

export interface VehicleOption {
  id: string;
  name: string;
  localName: string;
  capacityKg: number;
  ratePerKmInr: number;
  baseLoadingFeeInr: number;
  isRefrigerated: boolean;
  maxTripHoursRecommended: number;
}

export interface TransportInputs {
  quantityKg: number;
  distanceKm: number;
  selectedVehicleId: string;
  produceShelfLifeDays: number;
  estimatedTransitHours: number;
  dieselFuelRateInrPerLitre: number;
}

export interface TransportResult {
  vehicle: VehicleOption;
  tripsRequired: number;
  totalDistanceKm: number;
  fuelAndVehicleCostInr: number;
  loadingUnloadingCostInr: number;
  totalCostInr: number;
  costPerKgInr: number;
  transitSpoilageRisk: 'Low' | 'Moderate' | 'High';
  riskExplanation: string;
  mitigationTips: string[];
}

export interface FarmerProfile {
  name: string;
  farmName: string;
  district: string;
  state: string;
  primaryCrop: CropType;
  totalFarmAreaAcres: number;
  nearestColdStoreKm: number;
  nearestApmcMandi: string;
  selectedLanguage: Language;
}
