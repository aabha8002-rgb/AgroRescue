import React from 'react';
import {
  Boxes,
  AlertTriangle,
  TrendingUp,
  ShieldCheck,
  Scale,
  Camera,
  PlusCircle,
  Clock,
  ArrowUpRight,
  ChevronRight,
  Sprout,
  CheckCircle2,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { HarvestBatch, ScanResult, Language } from '../types';
import { translations } from '../i18n/translations';
import { INITIAL_REMINDERS } from '../data/initialBatches';

interface DashboardProps {
  batches: HarvestBatch[];
  recentScans: ScanResult[];
  currentLanguage: Language;
  onNavigate: (page: string) => void;
  onSelectBatchForInspection: (batch: HarvestBatch) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  batches,
  recentScans,
  currentLanguage,
  onNavigate,
  onSelectBatchForInspection,
}) => {
  const t = translations[currentLanguage];

  // Aggregate stats
  const totalHarvestedKg = batches.reduce((sum, b) => sum + b.quantityKg, 0);
  const activeBatchesCount = batches.length;
  const urgentBatches = batches.filter((b) => b.riskLevel === 'Urgent');
  const warningBatches = batches.filter((b) => b.riskLevel === 'Warning');
  const totalEstimatedValueInr = batches.reduce((sum, b) => sum + b.estimatedMarketValueInr, 0);

  // Estimated recovered value: Value saved through prompt triage
  const estimatedRecoveredValueInr = 68400;

  // Weekly harvest & loss data (kg) for Indian cluster
  const weeklyTrendData = [
    { day: 'Mon', harvested: 3200, lossPrevented: 480, actualLoss: 60 },
    { day: 'Tue', harvested: 4100, lossPrevented: 620, actualLoss: 90 },
    { day: 'Wed', harvested: 2800, lossPrevented: 390, actualLoss: 50 },
    { day: 'Thu', harvested: 5200, lossPrevented: 820, actualLoss: 110 },
    { day: 'Fri', harvested: 4600, lossPrevented: 710, actualLoss: 85 },
    { day: 'Sat', harvested: 3900, lossPrevented: 580, actualLoss: 70 },
    { day: 'Sun', harvested: 1900, lossPrevented: 290, actualLoss: 40 },
  ];

  // Quality distribution counts
  const gradeCounts = {
    'Grade A': batches.filter((b) => b.grade === 'Grade A').length,
    'Grade B+': batches.filter((b) => b.grade === 'Grade B+').length,
    'Grade B': batches.filter((b) => b.grade === 'Grade B').length,
    'Grade C': batches.filter((b) => b.grade === 'Grade C').length,
  };

  const maxHarvested = Math.max(...weeklyTrendData.map((d) => d.harvested));

  return (
    <div className="space-y-6">
      {/* Demonstration Banner & Context */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-950">
        <div className="flex items-center gap-2">
          <span className="font-bold text-amber-800 uppercase tracking-wide">
            {t.actualVsPredictedBadge}
          </span>
          <span className="text-stone-400">|</span>
          <p className="text-stone-700">{t.demoNotice}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-stone-500">APMC Index:</span>
          <span className="font-mono font-bold text-stone-900">₹18.50/kg</span>
          <span className="text-emerald-700 font-semibold text-[11px]">(+₹2.00 today)</span>
        </div>
      </div>

      {/* KPI Cards Strip (5 metrics) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        {/* Metric 1: Total Harvest */}
        <div className="liquid-glass rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>{t.kpiTotalHarvest}</span>
            <Boxes className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-extrabold text-stone-900 font-mono tabular-nums">
              {totalHarvestedKg.toLocaleString()} <span className="text-sm font-sans font-normal text-stone-500">kg</span>
            </div>
            <div className="text-[11px] text-stone-500 mt-0.5">
              Across 5 active farm blocks
            </div>
          </div>
        </div>

        {/* Metric 2: Active Batches */}
        <div className="liquid-glass rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>{t.kpiActiveBatches}</span>
            <Layers className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-extrabold text-stone-900 font-mono tabular-nums">
              {activeBatchesCount}
            </div>
            <div className="text-[11px] text-emerald-700 font-medium mt-0.5">
              3 Tomato · 1 Onion · 1 Capsicum
            </div>
          </div>
        </div>

        {/* Metric 3: Urgent Inspection Needed */}
        <div className="liquid-glass rounded-2xl p-4 flex flex-col justify-between border-rose-200/50 bg-rose-50/30">
          <div className="flex items-center justify-between text-rose-800 text-xs font-semibold">
            <span>{t.kpiUrgentInspection}</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-extrabold text-rose-700 font-mono tabular-nums">
              {urgentBatches.length} <span className="text-xs font-sans font-normal text-rose-600">lot</span>
            </div>
            <div className="text-[11px] text-rose-600 font-medium mt-0.5">
              &lt; 36 hours shelf life left
            </div>
          </div>
        </div>

        {/* Metric 4: Estimated Crop Value */}
        <div className="liquid-glass rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-stone-500 text-xs">
            <span>{t.kpiEstValue}</span>
            <TrendingUp className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-extrabold text-stone-900 font-mono tabular-nums">
              ₹{(totalEstimatedValueInr / 1000).toFixed(1)}k
            </div>
            <div className="text-[11px] text-stone-500 mt-0.5">
              Market valuation at current rate
            </div>
          </div>
        </div>

        {/* Metric 5: Estimated Value Recovered */}
        <div className="liquid-glass rounded-2xl p-4 flex flex-col justify-between border-emerald-200/50 bg-emerald-50/40">
          <div className="flex items-center justify-between text-emerald-900 text-xs font-semibold">
            <span>{t.kpiRecoveredValue}</span>
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="mt-2">
            <div className="text-2xl font-extrabold text-emerald-800 font-mono tabular-nums">
              ₹{(estimatedRecoveredValueInr / 1000).toFixed(1)}k
            </div>
            <div className="text-[11px] text-emerald-700 font-medium mt-0.5">
              Prevented post-harvest losses
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions Strip */}
      <div className="liquid-glass rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-stone-800 uppercase tracking-wider">
            Quick Actions
          </span>
          <span className="text-stone-300">|</span>
          <span className="text-xs text-stone-600">
            Rapid post-harvest intervention tools
          </span>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onNavigate('scanner')}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-900 rounded-xl shadow-sm transition-all active:scale-95"
          >
            <Camera className="w-4 h-4 text-lime-300" />
            <span>{t.quickScan}</span>
          </button>
          <button
            onClick={() => onNavigate('batches')}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-stone-800 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-xl transition-all active:scale-95"
          >
            <PlusCircle className="w-4 h-4 text-emerald-700" />
            <span>{t.quickAddBatch}</span>
          </button>
          <button
            onClick={() => onNavigate('sell-store')}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-stone-800 bg-white hover:bg-stone-50 border border-stone-200/80 rounded-xl transition-all active:scale-95"
          >
            <Scale className="w-4 h-4 text-emerald-700" />
            <span>{t.quickCompare}</span>
          </button>
        </div>
      </div>

      {/* Charts Grid: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Harvest & Loss Trend (2 cols) */}
        <div className="lg:col-span-2 liquid-glass rounded-2xl p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-stone-200/60">
            <div>
              <h2 className="text-sm font-bold text-stone-900">
                {t.weeklyLossTitle}
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Actual volume vs. spoilage mitigated via prompt cold-chain & processing triage
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-stone-600">
                <span className="w-3 h-3 rounded-sm bg-emerald-800 inline-block" />
                {t.harvestVolume}
              </span>
              <span className="flex items-center gap-1.5 text-stone-600">
                <span className="w-3 h-3 rounded-sm bg-lime-500 inline-block" />
                {t.preventedLoss}
              </span>
              <span className="flex items-center gap-1.5 text-stone-600">
                <span className="w-3 h-3 rounded-sm bg-rose-400 inline-block" />
                {t.actualLoss}
              </span>
            </div>
          </div>

          {/* SVG Bar & Area Visualization */}
          <div className="mt-4 pt-2">
            <div className="h-56 flex items-end justify-between gap-3 px-2">
              {weeklyTrendData.map((item, idx) => {
                const harvestHeight = (item.harvested / maxHarvested) * 160;
                const preventedHeight = (item.lossPrevented / maxHarvested) * 160;
                const lossHeight = Math.max((item.actualLoss / maxHarvested) * 160, 6);

                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1 h-full justify-end group">
                    <div className="text-[10px] font-mono text-stone-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      {item.harvested}kg
                    </div>
                    <div className="w-full max-w-[36px] flex items-end justify-center gap-1 h-44">
                      {/* Main harvest bar */}
                      <div
                        style={{ height: `${harvestHeight}px` }}
                        className="w-4 rounded-t-md bg-emerald-800 group-hover:bg-emerald-700 transition-all relative"
                        title={`Harvested: ${item.harvested}kg`}
                      />
                      {/* Loss prevented / Loss bar stacked */}
                      <div className="w-2.5 flex flex-col justify-end h-full">
                        <div
                          style={{ height: `${lossHeight}px` }}
                          className="w-full bg-rose-400 rounded-t-sm"
                          title={`Loss: ${item.actualLoss}kg`}
                        />
                        <div
                          style={{ height: `${preventedHeight}px` }}
                          className="w-full bg-lime-500 rounded-b-sm"
                          title={`Saved: ${item.lossPrevented}kg`}
                        />
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-stone-600 mt-1">
                      {item.day}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="mt-3 pt-3 border-t border-stone-200/60 flex items-center justify-between text-xs text-stone-500">
              <span>Weekly Total Harvested: <strong className="text-stone-800 font-mono">25,700 kg</strong></span>
              <span>Total Spoilage Mitigated: <strong className="text-emerald-700 font-mono">3,890 kg (87.2% Saved)</strong></span>
            </div>
          </div>
        </div>

        {/* Batch Quality Distribution (1 col) */}
        <div className="liquid-glass rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-200/60">
              <h2 className="text-sm font-bold text-stone-900">
                {t.batchQualityTitle}
              </h2>
              <span className="text-xs text-stone-500">{activeBatchesCount} batches</span>
            </div>

            <div className="space-y-3.5 mt-4">
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-emerald-900">Grade A (Optimal / Export)</span>
                  <span className="font-mono text-stone-700">{gradeCounts['Grade A']} batch · 7,700 kg</span>
                </div>
                <div className="w-full h-2 bg-stone-100 rounded-full mt-1.5 overflow-hidden">
                  <div className="h-full bg-emerald-700 rounded-full" style={{ width: '55%' }} />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-teal-900">Grade B+ (Prime Table Ripe)</span>
                  <span className="font-mono text-stone-700">{gradeCounts['Grade B+']} batch · 2,400 kg</span>
                </div>
                <div className="w-full h-2 bg-stone-100 rounded-full mt-1.5 overflow-hidden">
                  <div className="h-full bg-teal-600 rounded-full" style={{ width: '22%' }} />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-amber-900">Grade B (Commercial Mandi)</span>
                  <span className="font-mono text-stone-700">{gradeCounts['Grade B']} batch · 1,200 kg</span>
                </div>
                <div className="w-full h-2 bg-stone-100 rounded-full mt-1.5 overflow-hidden">
                  <div className="h-full bg-amber-500 rounded-full" style={{ width: '12%' }} />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-rose-900">Grade C (Immediate Triage)</span>
                  <span className="font-mono text-stone-700">{gradeCounts['Grade C']} batch · 1,800 kg</span>
                </div>
                <div className="w-full h-2 bg-stone-100 rounded-full mt-1.5 overflow-hidden">
                  <div className="h-full bg-rose-500 rounded-full" style={{ width: '11%' }} />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 rounded-xl bg-emerald-50/80 border border-emerald-900/10 text-xs text-emerald-950">
            <div className="font-bold flex items-center gap-1.5 text-emerald-900">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
              Loss Prevention Target
            </div>
            <p className="mt-1 text-stone-600 leading-relaxed">
              Triage Grade C lots to local tomato puree cottage units to recover up to ₹25,200 before mold spores spread.
            </p>
          </div>
        </div>
      </div>

      {/* Priority Batches Table & Recent Scans */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Priority Batches (2 cols) */}
        <div className="lg:col-span-2 liquid-glass rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-stone-200/60">
            <div>
              <h2 className="text-sm font-bold text-stone-900">
                {t.priorityBatchesTitle}
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Sorted by remaining shelf-life urgency
              </p>
            </div>
            <button
              onClick={() => onNavigate('batches')}
              className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1"
            >
              {t.viewAllBatches}
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-stone-200 text-stone-500 font-medium">
                  <th className="py-2.5 px-3">{t.batchCode}</th>
                  <th className="py-2.5 px-3">{t.crop} &amp; {t.variety}</th>
                  <th className="py-2.5 px-3 text-right">{t.quantity}</th>
                  <th className="py-2.5 px-3 text-center">{t.freshnessScore}</th>
                  <th className="py-2.5 px-3 text-center">{t.shelfLifeDays}</th>
                  <th className="py-2.5 px-3 text-right">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {batches.map((batch) => (
                  <tr
                    key={batch.id}
                    className="hover:bg-stone-50/80 transition-colors cursor-pointer"
                    onClick={() => onSelectBatchForInspection(batch)}
                  >
                    <td className="py-3 px-3 font-mono font-bold text-stone-900">
                      {batch.batchCode}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-stone-900">{batch.crop}</div>
                      <div className="text-[11px] text-stone-500 truncate max-w-[150px]">{batch.variety}</div>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-semibold text-stone-900">
                      {batch.quantityKg.toLocaleString()} kg
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="font-mono font-bold text-xs tabular-nums text-stone-800">
                        {batch.currentFreshnessScore}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`text-xs font-bold font-mono ${
                          batch.riskLevel === 'Urgent'
                            ? 'text-rose-700'
                            : batch.riskLevel === 'Warning'
                            ? 'text-amber-700'
                            : 'text-emerald-700'
                        }`}
                      >
                        {batch.estimatedShelfLifeAmbientDays} {t.daysRemaining}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectBatchForInspection(batch);
                        }}
                        className="px-2.5 py-1 text-xs font-semibold text-emerald-800 hover:text-emerald-950 hover:bg-emerald-50 rounded-lg transition-colors"
                      >
                        Inspect &rarr;
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent AI Scan Results (1 col) */}
        <div className="liquid-glass rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-stone-200/60">
              <h2 className="text-sm font-bold text-stone-900">
                {t.recentScansTitle}
              </h2>
              <button
                onClick={() => onNavigate('scanner')}
                className="text-xs font-semibold text-emerald-800 hover:text-emerald-950"
              >
                + New Scan
              </button>
            </div>

            <div className="space-y-3 mt-3">
              {recentScans.map((scan) => (
                <div
                  key={scan.id}
                  className="p-3 rounded-xl bg-white/70 border border-stone-200/70 hover:border-emerald-700/40 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    {scan.imagePreviewUrl && (
                      <img
                        src={scan.imagePreviewUrl}
                        alt="Scanned produce preview"
                        className="w-14 h-14 rounded-lg object-cover border border-stone-200 shrink-0"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-stone-900 truncate">
                          {scan.crop} · {scan.grade}
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-800">
                          {scan.freshnessScore}%
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-600 line-clamp-2 mt-1">
                        {scan.visibleCondition}
                      </p>
                      <div className="mt-1.5 flex items-center justify-between text-[11px]">
                        <span className="text-stone-500 font-mono">{scan.timestamp}</span>
                        <span
                          className={`font-semibold ${
                            scan.riskLevel === 'Urgent'
                              ? 'text-rose-700'
                              : 'text-emerald-700'
                          }`}
                        >
                          {scan.shelfLifeAmbientDays}d ambient
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-stone-200/60">
            <button
              onClick={() => onNavigate('scanner')}
              className="w-full py-2 px-3 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors text-center"
            >
              Open AI Camera Scanner &rarr;
            </button>
          </div>
        </div>
      </div>

      {/* AI Recommendation & Action Reminders Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Loss Mitigation Recommendations (2 cols) */}
        <div className="lg:col-span-2 liquid-glass-forest text-white rounded-2xl p-5">
          <div className="flex items-center gap-2 pb-3 border-b border-white/10">
            <Sparkles className="w-4 h-4 text-lime-300" />
            <h2 className="text-sm font-bold text-white tracking-wide">
              {t.recommendationsTitle}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div className="p-3.5 rounded-xl bg-white/10 border border-white/10">
              <span className="text-xs font-bold text-lime-300 block">
                1. Immediate Mandi Dispatch for NSK-TOM-084
              </span>
              <p className="text-xs text-stone-200 mt-1 leading-relaxed">
                1,800 kg table-ripe tomatoes have 1.5 days remaining before skin collapse. Moving to morning Nashik APMC auction will recover ₹25,200 at ₹14/kg before decay sets in.
              </p>
              <button
                onClick={() => onNavigate('transport')}
                className="mt-2 text-xs font-semibold text-lime-300 hover:text-white flex items-center gap-1"
              >
                Arrange Bolero Transport &rarr;
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-white/10 border border-white/10">
              <span className="text-xs font-bold text-lime-300 block">
                2. Cold Hold Optimization for NSK-TOM-089
              </span>
              <p className="text-xs text-stone-200 mt-1 leading-relaxed">
                3,500 kg breaker-stage tomatoes scored 92% freshness. Holding in 12°C cold storage for 12 days is projected to generate +₹18,400 net surplus compared to selling today.
              </p>
              <button
                onClick={() => onNavigate('sell-store')}
                className="mt-2 text-xs font-semibold text-lime-300 hover:text-white flex items-center gap-1"
              >
                Run Financial Simulation &rarr;
              </button>
            </div>
          </div>
        </div>

        {/* Reminders & Cold Chain Checklist (1 col) */}
        <div className="liquid-glass rounded-2xl p-5">
          <div className="flex items-center justify-between pb-3 border-b border-stone-200/60">
            <h2 className="text-sm font-bold text-stone-900">
              {t.remindersTitle}
            </h2>
            <Clock className="w-4 h-4 text-stone-400" />
          </div>

          <div className="space-y-3 mt-3">
            {INITIAL_REMINDERS.map((rem) => (
              <div key={rem.id} className="p-2.5 rounded-xl bg-white/60 border border-stone-200/60 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-stone-900">{rem.title}</span>
                  <span className="text-[11px] font-mono text-stone-500">{rem.due}</span>
                </div>
                <p className="text-stone-600 mt-1 leading-relaxed text-[11px]">
                  {rem.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
