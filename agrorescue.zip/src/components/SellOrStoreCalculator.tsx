import React, { useState, useMemo } from 'react';
import {
  Scale,
  TrendingUp,
  DollarSign,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Percent,
  Truck,
  RotateCcw,
  CheckCircle2,
} from 'lucide-react';
import { CropType, Language, SellOrStoreInputs, SellOrStoreResult } from '../types';
import { translations } from '../i18n/translations';

interface SellOrStoreCalculatorProps {
  currentLanguage: Language;
}

export const SellOrStoreCalculator: React.FC<SellOrStoreCalculatorProps> = ({
  currentLanguage,
}) => {
  const t = translations[currentLanguage];

  // User inputs
  const [inputs, setInputs] = useState<SellOrStoreInputs>({
    crop: 'Tomato',
    quantityKg: 3000,
    todayPricePerKg: 15, // ₹15/kg
    expectedFuturePricePerKg: 24, // ₹24/kg after 20 days
    storageDurationDays: 20,
    coldStorageMonthlyRatePerKg: 2.2, // ₹2.2/kg per month (~₹45-50 per crate)
    handlingAndElectricityInr: 1800, // loading, sorting, crate rent
    transportToMandiTodayInr: 1200,
    transportToStorageInr: 800,
    transportFromStorageToMandiInr: 1400,
    expectedSpoilagePercent: 6, // 6% weight shrinkage + sorting cull
  });

  // Calculate outputs
  const result: SellOrStoreResult = useMemo(() => {
    const {
      quantityKg,
      todayPricePerKg,
      expectedFuturePricePerKg,
      storageDurationDays,
      coldStorageMonthlyRatePerKg,
      handlingAndElectricityInr,
      transportToMandiTodayInr,
      transportToStorageInr,
      transportFromStorageToMandiInr,
      expectedSpoilagePercent,
    } = inputs;

    // Scenario 1: Sell Today
    const grossSellToday = quantityKg * todayPricePerKg;
    const sellTodayNetRevenue = grossSellToday - transportToMandiTodayInr;

    // Scenario 2: Store and Sell in Future
    const storageDurationMonths = storageDurationDays / 30;
    const storageRentTotal = quantityKg * coldStorageMonthlyRatePerKg * storageDurationMonths;
    const totalStorageAndHandling = storageRentTotal + handlingAndElectricityInr;

    const totalStorageTransport = transportToStorageInr + transportFromStorageToMandiInr;

    const estimatedSpoilageKg = quantityKg * (expectedSpoilagePercent / 100);
    const salableStoredQuantityKg = quantityKg - estimatedSpoilageKg;

    const grossRevenueStored = salableStoredQuantityKg * expectedFuturePricePerKg;
    const storeNetRevenue = grossRevenueStored - totalStorageAndHandling - totalStorageTransport;

    const netBenefitOfStoring = storeNetRevenue - sellTodayNetRevenue;

    // Break-even future selling price per kg:
    // SalableQty * BreakEvenPrice - (TotalStorageAndHandling + TotalStorageTransport) = sellTodayNetRevenue
    // BreakEvenPrice = (sellTodayNetRevenue + TotalStorageAndHandling + TotalStorageTransport) / SalableQty
    const breakEvenFuturePricePerKg =
      salableStoredQuantityKg > 0
        ? (sellTodayNetRevenue + totalStorageAndHandling + totalStorageTransport) / salableStoredQuantityKg
        : 0;

    let recommendation: 'SELL_TODAY' | 'STORE_PRODUCE' | 'NEUTRAL' = 'NEUTRAL';
    let reasoning = '';

    if (netBenefitOfStoring > 2000) {
      recommendation = 'STORE_PRODUCE';
      reasoning = `Storing is projected to yield +₹${Math.round(netBenefitOfStoring).toLocaleString()} extra net profit after storage fees, transport, and ${expectedSpoilagePercent}% spoilage deduction.`;
    } else if (netBenefitOfStoring < -2000) {
      recommendation = 'SELL_TODAY';
      reasoning = `Selling today provides higher net return. Storing will incur a net loss of ₹${Math.abs(Math.round(netBenefitOfStoring)).toLocaleString()} due to storage fees and produce weight loss.`;
    } else {
      recommendation = 'NEUTRAL';
      reasoning = `Both options yield roughly equivalent returns (difference under ₹2,000). Selling today avoids market volatility risk.`;
    }

    return {
      sellTodayNetRevenue,
      storeNetRevenue,
      netBenefitOfStoring,
      breakEvenFuturePricePerKg,
      estimatedSpoilageKg,
      estimatedStorageCosts: totalStorageAndHandling,
      estimatedTransportTotal: totalStorageTransport,
      recommendation,
      reasoning,
    };
  }, [inputs]);

  const handleResetDefaults = () => {
    setInputs({
      crop: 'Tomato',
      quantityKg: 3000,
      todayPricePerKg: 15,
      expectedFuturePricePerKg: 24,
      storageDurationDays: 20,
      coldStorageMonthlyRatePerKg: 2.2,
      handlingAndElectricityInr: 1800,
      transportToMandiTodayInr: 1200,
      transportToStorageInr: 800,
      transportFromStorageToMandiInr: 1400,
      expectedSpoilagePercent: 6,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="liquid-glass rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
            {t.sellStoreTitle}
          </h1>
          <p className="text-xs text-stone-600 mt-1 max-w-2xl leading-relaxed">
            {t.sellStoreSubtitle}
          </p>
        </div>

        <button
          onClick={handleResetDefaults}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5 text-stone-400" />
          <span>Reset Sample Values</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Form Inputs (Left) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-200">
              Produce &amp; Price Parameters
            </h2>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-bold text-stone-800 block mb-1">{t.crop}</label>
                <select
                  value={inputs.crop}
                  onChange={(e) => setInputs({ ...inputs, crop: e.target.value as CropType })}
                  className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900 font-semibold"
                >
                  <option value="Tomato">Tomato</option>
                  <option value="Onion">Onion</option>
                  <option value="Potato">Potato</option>
                  <option value="Capsicum">Capsicum</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-stone-800 block mb-1">Total Quantity (kg)</label>
                <input
                  type="number"
                  value={inputs.quantityKg}
                  onChange={(e) => setInputs({ ...inputs, quantityKg: Math.max(0, Number(e.target.value)) })}
                  className="w-full p-2.5 rounded-xl bg-white border border-stone-200 font-mono font-bold text-stone-900"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-bold text-stone-800 block mb-1">
                  {t.todayOfferPrice}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 font-mono">₹</span>
                  <input
                    type="number"
                    step="0.5"
                    value={inputs.todayPricePerKg}
                    onChange={(e) => setInputs({ ...inputs, todayPricePerKg: Math.max(0, Number(e.target.value)) })}
                    className="w-full pl-7 pr-3 py-2 rounded-xl bg-white border border-stone-200 font-mono font-bold text-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-800 block mb-1">
                  {t.expectedFuturePrice}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 font-mono">₹</span>
                  <input
                    type="number"
                    step="0.5"
                    value={inputs.expectedFuturePricePerKg}
                    onChange={(e) => setInputs({ ...inputs, expectedFuturePricePerKg: Math.max(0, Number(e.target.value)) })}
                    className="w-full pl-7 pr-3 py-2 rounded-xl bg-white border border-stone-200 font-mono font-bold text-emerald-800"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-stone-200">
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                Storage &amp; Spoilage Overhead
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="font-medium text-stone-700 block mb-1">Holding Days</label>
                  <input
                    type="number"
                    value={inputs.storageDurationDays}
                    onChange={(e) => setInputs({ ...inputs, storageDurationDays: Math.max(1, Number(e.target.value)) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                </div>

                <div>
                  <label className="font-medium text-stone-700 block mb-1">Rent (₹/kg/mo)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={inputs.coldStorageMonthlyRatePerKg}
                    onChange={(e) => setInputs({ ...inputs, coldStorageMonthlyRatePerKg: Math.max(0, Number(e.target.value)) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                </div>

                <div>
                  <label className="font-medium text-stone-700 block mb-1">Expected Loss (%)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={inputs.expectedSpoilagePercent}
                    onChange={(e) => setInputs({ ...inputs, expectedSpoilagePercent: Math.max(0, Number(e.target.value)) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono text-rose-700 font-semibold"
                  />
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-stone-200">
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                Logistics &amp; Mandi Transport
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="font-medium text-stone-700 block mb-1">Today Mandi (₹)</label>
                  <input
                    type="number"
                    value={inputs.transportToMandiTodayInr}
                    onChange={(e) => setInputs({ ...inputs, transportToMandiTodayInr: Math.max(0, Number(e.target.value)) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                </div>

                <div>
                  <label className="font-medium text-stone-700 block mb-1">To Cold Store (₹)</label>
                  <input
                    type="number"
                    value={inputs.transportToStorageInr}
                    onChange={(e) => setInputs({ ...inputs, transportToStorageInr: Math.max(0, Number(e.target.value)) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                </div>

                <div>
                  <label className="font-medium text-stone-700 block mb-1">Store to Mandi (₹)</label>
                  <input
                    type="number"
                    value={inputs.transportFromStorageToMandiInr}
                    onChange={(e) => setInputs({ ...inputs, transportFromStorageToMandiInr: Math.max(0, Number(e.target.value)) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Financial Decision & Comparative Analysis (Right) */}
        <div className="lg:col-span-6 space-y-4">
          {/* Recommendation Banner */}
          <div
            className={`liquid-glass rounded-2xl p-5 border-2 ${
              result.recommendation === 'STORE_PRODUCE'
                ? 'border-emerald-600 bg-emerald-50/50 text-emerald-950'
                : result.recommendation === 'SELL_TODAY'
                ? 'border-amber-600 bg-amber-50/50 text-amber-950'
                : 'border-stone-400 bg-stone-50 text-stone-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider">
                {result.recommendation === 'STORE_PRODUCE'
                  ? t.decisionStore
                  : result.recommendation === 'SELL_TODAY'
                  ? t.decisionSellToday
                  : t.decisionNeutral}
              </span>
              <span className="text-xs font-mono font-bold">
                Net Benefit:{' '}
                <span className={result.netBenefitOfStoring >= 0 ? 'text-emerald-800' : 'text-rose-700'}>
                  {result.netBenefitOfStoring >= 0 ? '+' : ''}₹{Math.round(result.netBenefitOfStoring).toLocaleString()}
                </span>
              </span>
            </div>
            <p className="text-xs mt-2 leading-relaxed opacity-90">
              {result.reasoning}
            </p>
          </div>

          {/* Comparative Revenue Breakdown */}
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-200">
              Financial Outcome Comparison
            </h2>

            <div className="grid grid-cols-2 gap-4">
              {/* Option A: Sell Today */}
              <div className="p-4 rounded-xl bg-white border border-stone-200 space-y-2">
                <span className="text-xs font-bold text-stone-600 block">
                  Option A: Sell Today at ₹{inputs.todayPricePerKg}/kg
                </span>
                <div className="text-2xl font-black font-mono text-stone-900 tabular-nums">
                  ₹{Math.round(result.sellTodayNetRevenue).toLocaleString()}
                </div>
                <div className="text-[11px] text-stone-500 space-y-0.5 pt-1 border-t border-stone-100">
                  <div className="flex justify-between">
                    <span>Gross Value:</span>
                    <span className="font-mono">₹{(inputs.quantityKg * inputs.todayPricePerKg).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-rose-700">
                    <span>Transport deduction:</span>
                    <span className="font-mono">-₹{inputs.transportToMandiTodayInr}</span>
                  </div>
                  <div className="flex justify-between font-semibold text-stone-800 pt-0.5">
                    <span>Produce Risk:</span>
                    <span className="text-emerald-700">Zero Spoilage</span>
                  </div>
                </div>
              </div>

              {/* Option B: Store & Sell Later */}
              <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200 space-y-2">
                <span className="text-xs font-bold text-emerald-900 block">
                  Option B: Store &amp; Sell at ₹{inputs.expectedFuturePricePerKg}/kg
                </span>
                <div className="text-2xl font-black font-mono text-emerald-900 tabular-nums">
                  ₹{Math.round(result.storeNetRevenue).toLocaleString()}
                </div>
                <div className="text-[11px] text-stone-600 space-y-0.5 pt-1 border-t border-emerald-100">
                  <div className="flex justify-between">
                    <span>Salable Weight:</span>
                    <span className="font-mono font-semibold">{Math.round(inputs.quantityKg - result.estimatedSpoilageKg).toLocaleString()} kg</span>
                  </div>
                  <div className="flex justify-between text-rose-700">
                    <span>Storage + Handling:</span>
                    <span className="font-mono">-₹{Math.round(result.estimatedStorageCosts).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-rose-700">
                    <span>Total Logistics:</span>
                    <span className="font-mono">-₹{result.estimatedTransportTotal.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Break-Even Highlight */}
            <div className="p-4 rounded-xl bg-stone-900 text-white flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-stone-300 block">
                  {t.breakEvenPrice}
                </span>
                <span className="text-[11px] text-stone-400 mt-0.5 block">
                  Minimum future Mandi rate required to justify storing
                </span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black font-mono text-lime-300 tabular-nums">
                  ₹{result.breakEvenFuturePricePerKg.toFixed(2)}
                </span>
                <span className="text-xs text-stone-300 block font-normal">per kg</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-600 leading-relaxed">
              <strong>Farmer Advisory Rule:</strong> If anticipated Mandi rates after {inputs.storageDurationDays} days will NOT exceed <strong className="font-mono text-stone-900">₹{result.breakEvenFuturePricePerKg.toFixed(2)}/kg</strong>, selling immediately avoids cold storage rental debt and potential produce dehydration losses.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
