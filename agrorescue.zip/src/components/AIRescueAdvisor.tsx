import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  BotMessageSquare,
  AlertCircle,
  HelpCircle,
  CheckCircle2,
  RotateCcw,
  Boxes,
} from 'lucide-react';
import { Language, HarvestBatch } from '../types';
import { translations } from '../i18n/translations';

interface AIRescueAdvisorProps {
  currentLanguage: Language;
  batches: HarvestBatch[];
  autoStartListening?: boolean;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const AIRescueAdvisor: React.FC<AIRescueAdvisorProps> = ({
  currentLanguage,
  batches,
  autoStartListening = false,
}) => {
  const t = translations[currentLanguage];

  const [inputQuestion, setInputQuestion] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome',
      sender: 'assistant',
      text:
        currentLanguage === 'hi'
          ? 'नमस्ते! मैं आपका एग्रोरेस्क्यू सहायक हूँ। आप अपने फसल लॉट, कोल्ड स्टोरेज तापमान या मंडी भाव के बारे में आवाज से या लिखकर पूछ सकते हैं।'
          : currentLanguage === 'mr'
          ? 'नमस्कार! मी तुमचा ॲग्रोरेस्क्यू सहाय्यक आहे. तुम्ही काढणी लॉट, शीतगृह तापमान किंवा बाजारभावाबद्दल बोलून किंवा लिहून प्रश्न विचारू शकता.'
          : 'Hello! I am your AgroRescue post-harvest advisor. You can speak or type questions about your harvest batches, cold storage temperatures, or mandi pricing decisions.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [voiceOutputEnabled, setVoiceOutputEnabled] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Common quick questions by language
  const quickQuestions =
    currentLanguage === 'hi'
      ? [
          'टमाटर लॉट NSK-TOM-084 को सड़ने से कैसे बचाएं?',
          'क्या आलू और टमाटर को एक ही शेड में रख सकते हैं?',
          'कोल्ड स्टोर का तापमान कितना होना चाहिए?',
          'नरम पड़े टमाटरों से मूल्य कैसे वसूलें?',
        ]
      : currentLanguage === 'mr'
      ? [
          'लॉट NSK-TOM-084 चे नुकसान कसे टाळावे?',
          'कांदा आणि टोमॅटो एकत्र साठवणे योग्य आहे का?',
          'टोमॅटो शीतगृहात ठेवण्यासाठी योग्य तापमान कोणते?',
          'मऊ झालेल्या टोमॅटोपासून काय उत्पादन करता येईल?',
        ]
      : [
          'How do I triage softening batch NSK-TOM-084?',
          'Can I store onions and tomatoes in the same shed?',
          'What is the optimum cold storage temperature for tomatoes?',
          'How can I recover value from bruised tomatoes locally?',
        ];

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    // Set recognition language matching app language
    recognition.lang =
      currentLanguage === 'hi'
        ? 'hi-IN'
        : currentLanguage === 'mr'
        ? 'mr-IN'
        : 'en-IN';

    recognition.onstart = () => {
      setIsListening(true);
      setSpeechError(null);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputQuestion(transcript);
      setIsListening(false);
      // Auto-submit recognized question
      handleSendQuestion(transcript);
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsListening(false);
      if (event.error === 'not-allowed') {
        setSpeechError(t.micPermissionError);
      } else if (event.error === 'no-speech') {
        setSpeechError('No speech was detected. Please try again or type below.');
      } else {
        setSpeechError(`Voice input error: ${event.error}`);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    if (autoStartListening) {
      startListening();
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
      stopSpeaking();
    };
  }, [currentLanguage]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startListening = () => {
    setSpeechError(null);
    stopSpeaking();

    if (!speechSupported || !recognitionRef.current) {
      setSpeechError(t.speechNotSupported);
      return;
    }

    try {
      recognitionRef.current.lang =
        currentLanguage === 'hi'
          ? 'hi-IN'
          : currentLanguage === 'mr'
          ? 'mr-IN'
          : 'en-IN';
      recognitionRef.current.start();
    } catch (e) {
      console.warn('Recognition start error:', e);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  };

  const speakResponse = (text: string) => {
    if (!voiceOutputEnabled || !('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang =
      currentLanguage === 'hi'
        ? 'hi-IN'
        : currentLanguage === 'mr'
        ? 'mr-IN'
        : 'en-IN';
    utterance.rate = 0.95;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleSendQuestion = async (textToSend?: string) => {
    const query = (textToSend || inputQuestion).trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuestion('');
    setIsLoading(true);
    setSpeechError(null);

    try {
      const response = await fetch('/api/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: query,
          language: currentLanguage,
          batchContext: batches.map((b) => ({
            code: b.batchCode,
            crop: b.crop,
            quantity: `${b.quantityKg} kg`,
            freshness: `${b.currentFreshnessScore}%`,
            risk: b.riskLevel,
            shelfLifeDays: b.estimatedShelfLifeAmbientDays,
            location: b.location,
          })),
        }),
      });

      const data = await response.json();
      const answer = data.answer || 'Advice unavailable.';

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Speak response aloud if enabled
      speakResponse(answer);
    } catch (err) {
      console.error('Advisor request error:', err);
      const fallbackMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text:
          currentLanguage === 'hi'
            ? 'सलाह: खराब होने वाले टमाटरों को तुरंत अलग करें और छायादार हवादार स्थान पर रखें ताकि बाकी फसल सुरक्षित रहे।'
            : currentLanguage === 'mr'
            ? 'सल्ला: खराब होणारा माल त्वरित वेगळा करा आणि हवेशीर थंड जागी ठेवा जेणेकरून बाकी माल टिकेल.'
            : 'Immediate action: Isolate softening produce to prevent rot spread. Keep produce in shaded, ventilated crates.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="liquid-glass rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BotMessageSquare className="w-5 h-5 text-emerald-800" />
            <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
              {t.voiceAdvisorTitle}
            </h1>
          </div>
          <p className="text-xs text-stone-600 mt-1 leading-relaxed">
            {t.voiceAdvisorSubtitle}
          </p>
        </div>

        {/* Voice Output Toggle & Stop Audio Button */}
        <div className="flex items-center gap-2">
          {isSpeaking && (
            <button
              onClick={stopSpeaking}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl transition-colors animate-pulse"
            >
              <VolumeX className="w-4 h-4" />
              <span>{t.stopAudioButton}</span>
            </button>
          )}

          <button
            onClick={() => {
              if (isSpeaking) stopSpeaking();
              setVoiceOutputEnabled(!voiceOutputEnabled);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors ${
              voiceOutputEnabled
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-stone-100 text-stone-500 border-stone-200'
            }`}
            title="Toggle read aloud speech synthesis"
          >
            {voiceOutputEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">Voice Output {voiceOutputEnabled ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* Mic Status & Error Alerts */}
      {speechError && (
        <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 mt-0.5 shrink-0" />
          <div className="flex-1">
            <span className="font-bold block">Microphone Notice</span>
            <span>{speechError}</span>
          </div>
        </div>
      )}

      {/* Main Chat Interface */}
      <div className="liquid-glass rounded-2xl flex flex-col h-[520px] overflow-hidden">
        {/* Messages Stream */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-2xl text-xs leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-emerald-800 text-white shadow-sm rounded-br-none'
                    : 'bg-white border border-stone-200 text-stone-900 shadow-sm rounded-bl-none'
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>
                <span
                  className={`text-[10px] font-mono mt-1.5 block text-right opacity-70 ${
                    msg.sender === 'user' ? 'text-stone-200' : 'text-stone-400'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs text-stone-500 p-2">
              <Sparkles className="w-4 h-4 text-emerald-700 animate-spin" />
              <span>AgroRescue AI is consulting farm guidelines...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Listening Active Wave Indicator */}
        {isListening && (
          <div className="px-5 py-2.5 bg-emerald-900 text-white flex items-center justify-between animate-in fade-in text-xs">
            <div className="flex items-center gap-2 font-semibold">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-lime-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-lime-500"></span>
              </span>
              <span>{t.listeningActive}</span>
            </div>
            <button
              onClick={stopListening}
              className="px-2.5 py-1 text-xs font-bold bg-white/20 hover:bg-white/30 rounded-lg"
            >
              Cancel Listening
            </button>
          </div>
        )}

        {/* Suggested Quick Questions */}
        <div className="px-5 py-2.5 border-t border-stone-200/60 bg-stone-50/50 flex items-center gap-2 overflow-x-auto text-xs whitespace-nowrap scrollbar-none">
          <span className="text-stone-400 font-bold shrink-0">{t.popularQuestions}</span>
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendQuestion(q)}
              className="px-3 py-1 rounded-lg bg-white hover:bg-emerald-50 hover:text-emerald-950 border border-stone-200 text-stone-700 font-medium transition-colors shrink-0 text-xs"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Voice and Text Input Bar */}
        <div className="p-3.5 bg-white border-t border-stone-200 flex items-center gap-2">
          {/* Main Microphone Button */}
          <button
            onClick={isListening ? stopListening : startListening}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all shrink-0 ${
              isListening
                ? 'bg-rose-600 text-white shadow-lg animate-pulse'
                : 'bg-emerald-800 hover:bg-emerald-900 text-white shadow-sm'
            }`}
            title={isListening ? 'Stop listening' : 'Start microphone speech input'}
            aria-label="Microphone"
          >
            {isListening ? <MicOff className="w-5 h-5 text-white" /> : <Mic className="w-5 h-5 text-lime-300" />}
          </button>

          {/* Text Input Fallback */}
          <input
            type="text"
            value={inputQuestion}
            onChange={(e) => setInputQuestion(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSendQuestion();
            }}
            placeholder={isListening ? t.startListening : t.speakYourQuestion}
            disabled={isListening}
            className="flex-1 px-4 py-2.5 text-xs rounded-xl bg-stone-50 border border-stone-200 text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />

          {/* Send Button */}
          <button
            onClick={() => handleSendQuestion()}
            disabled={!inputQuestion.trim() || isLoading}
            className="w-11 h-11 rounded-xl bg-emerald-800 hover:bg-emerald-900 disabled:opacity-40 text-white flex items-center justify-center transition-all shrink-0 shadow-sm"
            title={t.askButton}
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
};
