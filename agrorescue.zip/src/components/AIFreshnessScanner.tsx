import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Info,
  Layers,
  ThermometerSnowflake,
  PlusCircle,
  X,
} from 'lucide-react';
import { ScanResult, CropType, Language, HarvestBatch } from '../types';
import { translations } from '../i18n/translations';

interface AIFreshnessScannerProps {
  currentLanguage: Language;
  onSaveAsBatch: (batchData: Partial<HarvestBatch>) => void;
  onScanCompleted: (result: ScanResult) => void;
}

export const AIFreshnessScanner: React.FC<AIFreshnessScannerProps> = ({
  currentLanguage,
  onSaveAsBatch,
  onScanCompleted,
}) => {
  const t = translations[currentLanguage];

  const [selectedCrop, setSelectedCrop] = useState<CropType>('Tomato');
  const [imagePreview, setImagePreview] = useState<string | null>(
    '/src/assets/images/tomato_inspection_sample_1792809676694.jpg'
  );
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [notes, setNotes] = useState<string>('Harvested yesterday morning from Nashik farm cluster, sorted on packing table.');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [savedBatchSuccess, setSavedBatchSuccess] = useState<boolean>(false);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Pre-loaded sample test images for instant evaluation
  const sampleImages = [
    {
      title: 'Sample 1: Table-Ripe Sorting Table (Nashik Hybrid)',
      url: '/src/assets/images/tomato_inspection_sample_1792809676694.jpg',
      crop: 'Tomato' as CropType,
      notes: 'Table ripe tomatoes showing varying firmness and dehydration at calyx stems.',
    },
    {
      title: 'Sample 2: Field Crates Ready for Stacking',
      url: '/src/assets/images/tomato_harvest_crate_1792809677112.jpg',
      crop: 'Tomato' as CropType,
      notes: 'Ventilated farm crates containing mixed breaker and ripe red fruits.',
    },
  ];

  const handleSelectSample = (sample: typeof sampleImages[0]) => {
    setImagePreview(sample.url);
    setSelectedCrop(sample.crop);
    setNotes(sample.notes);
    setImageBase64(null); // Will use sample URL or fallback
    setScanResult(null);
    setSavedBatchSuccess(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setImagePreview(result);
      setImageBase64(result);
      setScanResult(null);
      setSavedBatchSuccess(false);
    };
    reader.readAsDataURL(file);
  };

  // Camera integration
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setIsCameraActive(false);
      alert('Camera access could not be initialized. Please upload an image instead.');
    }
  };

  const captureCameraFrame = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setImagePreview(dataUrl);
      setImageBase64(dataUrl);
      stopCamera();
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const runAIScan = async () => {
    setIsScanning(true);
    setSavedBatchSuccess(false);

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          crop: selectedCrop,
          imageBase64: imageBase64 || imagePreview,
          notes,
        }),
      });

      const data = await response.json();

      const fullResult: ScanResult = {
        id: `scan-${Date.now()}`,
        timestamp: new Date().toLocaleString(),
        crop: selectedCrop,
        freshnessScore: data.freshnessScore ?? 78,
        grade: data.grade ?? 'Grade B+',
        visibleCondition: data.visibleCondition ?? 'Good overall condition with minor ambient skin dehydration.',
        defectsIdentified: data.defectsIdentified ?? [],
        shelfLifeAmbientDays: data.shelfLifeAmbientDays ?? 3.5,
        shelfLifeColdStoreDays: data.shelfLifeColdStoreDays ?? 14,
        recommendedAction: data.recommendedAction ?? 'Local Mandi Dispatch or Short Cold Storage',
        riskLevel: data.riskLevel ?? 'Warning',
        valueRecoveryOptions: data.valueRecoveryOptions ?? [],
        storageTips: data.storageTips ?? 'Maintain 10°C - 13°C at 85-90% RH.',
        imagePreviewUrl: imagePreview || undefined,
      };

      setScanResult(fullResult);
      onScanCompleted(fullResult);
    } catch (err) {
      console.error('Scan execution error:', err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleCreateBatchFromScan = () => {
    if (!scanResult) return;

    onSaveAsBatch({
      crop: scanResult.crop,
      variety: selectedCrop === 'Tomato' ? 'Nashik Hybrid Selection' : 'Standard Field Variety',
      quantityKg: 2000,
      initialQuantityKg: 2000,
      currentFreshnessScore: scanResult.freshnessScore,
      grade: scanResult.grade,
      riskLevel: scanResult.riskLevel,
      storageType: 'Ventilated Crates',
      location: 'Grading Bay 1',
      estimatedShelfLifeAmbientDays: scanResult.shelfLifeAmbientDays,
      estimatedShelfLifeColdDays: scanResult.shelfLifeColdStoreDays,
      estimatedMarketValueInr: 36000,
      notes: `AI Scan diagnosis: ${scanResult.visibleCondition}. Recommended: ${scanResult.recommendedAction}`,
      imageUrl: scanResult.imagePreviewUrl,
      lastInspectedDate: new Date().toISOString().split('T')[0],
    });

    setSavedBatchSuccess(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="liquid-glass rounded-2xl p-5">
        <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
          {t.scannerTitle}
        </h1>
        <p className="text-xs text-stone-600 mt-1 max-w-2xl leading-relaxed">
          {t.scannerSubtitle}
        </p>
      </div>

      {/* Main Grid: Upload & Controls (Left) vs Diagnostics (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Image Input & Crop Parameters */}
        <div className="lg:col-span-5 space-y-4">
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            {/* Crop Selector */}
            <div>
              <label className="text-xs font-bold text-stone-800 block mb-1.5">
                {t.crop}
              </label>
              <select
                value={selectedCrop}
                onChange={(e) => setSelectedCrop(e.target.value as CropType)}
                className="w-full px-3 py-2 text-xs font-semibold rounded-xl bg-white border border-stone-200 text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-700"
              >
                <option value="Tomato">Tomato (टमाटर / टोमॅटो)</option>
                <option value="Onion">Onion (प्याज / कांदा)</option>
                <option value="Potato">Potato (आलू / बटाटा)</option>
                <option value="Capsicum">Capsicum (शिमला मिर्च / ढोबळी मिरची)</option>
                <option value="Green Chilli">Green Chilli (हरी मिर्च / मिरची)</option>
                <option value="Banana">Banana (केला / केळे)</option>
                <option value="Mango">Mango (आम / आंबा)</option>
                <option value="Cauliflower">Cauliflower (फूलगोभी / फ्लॉवर)</option>
              </select>
            </div>

            {/* Camera Viewport or Image Preview */}
            <div className="relative rounded-xl overflow-hidden border border-stone-200 bg-stone-100 aspect-4/3 flex items-center justify-center">
              {isCameraActive ? (
                <div className="relative w-full h-full bg-black">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-3 left-0 right-0 flex items-center justify-center gap-3">
                    <button
                      onClick={captureCameraFrame}
                      className="px-4 py-2 bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg flex items-center gap-1.5"
                    >
                      <Camera className="w-4 h-4" />
                      {t.capturePhoto}
                    </button>
                    <button
                      onClick={stopCamera}
                      className="px-3 py-2 bg-stone-900/80 text-white text-xs rounded-xl"
                    >
                      {t.cancel}
                    </button>
                  </div>
                </div>
              ) : imagePreview ? (
                <div className="relative w-full h-full group">
                  <img
                    src={imagePreview}
                    alt="Inspection sample"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-2 right-2 flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        setImagePreview(null);
                        setImageBase64(null);
                        setScanResult(null);
                      }}
                      className="p-1.5 rounded-lg bg-black/60 text-white hover:bg-black/80 transition-colors"
                      title="Clear photo"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6 text-stone-400">
                  <Camera className="w-10 h-10 mx-auto text-stone-300 mb-2" />
                  <p className="text-xs font-medium">No photo selected</p>
                </div>
              )}
            </div>

            {/* Upload & Camera Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold text-stone-800 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors shadow-sm"
              >
                <Upload className="w-4 h-4 text-emerald-700" />
                <span>{t.uploadPhoto}</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />

              <button
                type="button"
                onClick={startCamera}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-3 text-xs font-semibold text-stone-800 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors shadow-sm"
              >
                <Camera className="w-4 h-4 text-emerald-700" />
                <span>{t.useCamera}</span>
              </button>
            </div>

            {/* Field Notes */}
            <div>
              <label className="text-xs font-bold text-stone-800 block mb-1">
                Harvest Field Observations
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full p-2.5 text-xs rounded-xl bg-white border border-stone-200 text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-700"
                placeholder="e.g. Harvested 2 days ago, field crate vibration noted..."
              />
            </div>

            {/* Run AI Scan CTA */}
            <button
              onClick={runAIScan}
              disabled={isScanning || !imagePreview}
              className="w-full py-3 px-4 rounded-xl bg-emerald-800 hover:bg-emerald-900 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all active:scale-[0.99]"
            >
              {isScanning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-lime-300" />
                  <span>{t.analyzingProduce}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-lime-300" />
                  <span>Analyze Freshness &amp; Value Recovery</span>
                </>
              )}
            </button>
          </div>

          {/* Sample test photos row */}
          <div className="liquid-glass rounded-2xl p-4">
            <span className="text-xs font-bold text-stone-800 block mb-2">
              {t.trySamplePhotos}
            </span>
            <div className="space-y-2">
              {sampleImages.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelectSample(s)}
                  className="w-full p-2 rounded-xl text-left bg-white/70 hover:bg-emerald-50 border border-stone-200 text-xs flex items-center gap-3 transition-colors"
                >
                  <img
                    src={s.url}
                    alt={s.title}
                    className="w-12 h-12 rounded-lg object-cover border border-stone-200 shrink-0"
                  />
                  <div className="truncate">
                    <div className="font-semibold text-stone-900 truncate">{s.title}</div>
                    <div className="text-[11px] text-stone-500 truncate">{s.notes}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: AI Freshness Diagnosis & Triage */}
        <div className="lg:col-span-7">
          {scanResult ? (
            <div className="space-y-4">
              {/* Score & Risk Summary Banner */}
              <div
                className={`liquid-glass rounded-2xl p-5 border-2 ${
                  scanResult.riskLevel === 'Urgent'
                    ? 'border-rose-400 bg-rose-50/40'
                    : scanResult.riskLevel === 'Warning'
                    ? 'border-amber-400 bg-amber-50/40'
                    : 'border-emerald-500 bg-emerald-50/40'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-stone-500 uppercase tracking-wider">
                        {scanResult.crop} Assessment
                      </span>
                      <span className="text-stone-300">·</span>
                      <span className="text-xs font-semibold text-stone-700">
                        {scanResult.grade}
                      </span>
                    </div>
                    <h2 className="text-lg font-extrabold text-stone-900 mt-0.5">
                      {scanResult.recommendedAction}
                    </h2>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-right">
                      <span className="text-[11px] text-stone-500 block uppercase">
                        Freshness
                      </span>
                      <span className="text-3xl font-black font-mono text-stone-900 tabular-nums">
                        {scanResult.freshnessScore}%
                      </span>
                    </div>

                    <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-stone-200 flex items-center justify-center font-mono font-bold text-sm">
                      {scanResult.riskLevel === 'Urgent' ? (
                        <AlertTriangle className="w-6 h-6 text-rose-600" />
                      ) : (
                        <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Ambient vs Cold Shelf Life Pill Strip */}
                <div className="grid grid-cols-2 gap-3 mt-4 pt-3 border-t border-stone-200/60">
                  <div className="p-2.5 rounded-xl bg-white/70">
                    <span className="text-[11px] text-stone-500 block">
                      Ambient Shelf Life (28°–32°C)
                    </span>
                    <span className="text-sm font-bold font-mono text-stone-900">
                      {scanResult.shelfLifeAmbientDays} {t.daysRemaining}
                    </span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/70">
                    <span className="text-[11px] text-stone-500 block">
                      Cold Storage Life (12°C, 88% RH)
                    </span>
                    <span className="text-sm font-bold font-mono text-emerald-800">
                      {scanResult.shelfLifeColdStoreDays} {t.daysRemaining}
                    </span>
                  </div>
                </div>
              </div>

              {/* Detailed Visual Condition */}
              <div className="liquid-glass rounded-2xl p-5">
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                  {t.visibleCondition}
                </h3>
                <p className="text-xs text-stone-700 leading-relaxed">
                  {scanResult.visibleCondition}
                </p>

                {/* Identified Defects */}
                {scanResult.defectsIdentified.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-stone-200/60">
                    <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                      {t.defectsFound}
                    </h4>
                    <div className="space-y-2">
                      {scanResult.defectsIdentified.map((def, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-xl bg-white/60 border border-stone-200/80 flex items-start justify-between gap-3 text-xs"
                        >
                          <div>
                            <span className="font-bold text-stone-900">{def.name}</span>
                            <p className="text-stone-600 text-[11px] mt-0.5">{def.description}</p>
                          </div>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 ${
                              def.severity === 'High'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {def.severity} Severity
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Value Recovery Pathways */}
              <div className="liquid-glass rounded-2xl p-5">
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-3">
                  {t.valueRecoveryOptions}
                </h3>
                <div className="space-y-2.5">
                  {scanResult.valueRecoveryOptions.map((opt, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-white/80 border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <span className="font-bold text-stone-900 block">{opt.channel}</span>
                        <p className="text-stone-600 text-[11px] mt-0.5 leading-relaxed">{opt.action}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-[10px] text-stone-500 block">Recoverable Value</span>
                        <span className="font-mono font-bold text-emerald-800">{opt.estimatedValuePct}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Storage & Holding Guidance */}
              <div className="liquid-glass rounded-2xl p-5">
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ThermometerSnowflake className="w-4 h-4 text-emerald-700" />
                  {t.storageAdvice}
                </h3>
                <p className="text-xs text-stone-700 leading-relaxed bg-white/60 p-3 rounded-xl border border-stone-200">
                  {scanResult.storageTips}
                </p>

                {/* Save as Batch Action */}
                <div className="mt-4 pt-3 border-t border-stone-200/60 flex items-center justify-between">
                  <span className="text-xs text-stone-500">
                    Add this inspection to your active Harvest Batch Manager
                  </span>

                  <button
                    onClick={handleCreateBatchFromScan}
                    disabled={savedBatchSuccess}
                    className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-emerald-800 hover:bg-emerald-900 disabled:bg-emerald-950 rounded-xl transition-all shadow-sm"
                  >
                    <PlusCircle className="w-4 h-4 text-lime-300" />
                    <span>{savedBatchSuccess ? t.batchSavedSuccess : t.saveAsBatch}</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="liquid-glass rounded-2xl p-12 text-center h-full flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-800 flex items-center justify-center mb-3">
                <Camera className="w-8 h-8 text-emerald-700" />
              </div>
              <h3 className="text-sm font-bold text-stone-900">
                Ready for AI Crop Inspection
              </h3>
              <p className="text-xs text-stone-500 max-w-sm mt-1 leading-relaxed">
                Take a photo of your harvested crate or select one of the demonstration samples on the left to evaluate produce freshness, defects, and recovery avenues.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
