import React from 'react';
import {
  LayoutDashboard,
  ScanLine,
  Boxes,
  ThermometerSnowflake,
  Scale,
  Truck,
  BotMessageSquare,
  Settings,
  ChevronLeft,
  ChevronRight,
  Sprout,
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n/translations';

interface NavigationProps {
  activePage: string;
  onNavigate: (page: string) => void;
  currentLanguage: Language;
  isSidebarCollapsed: boolean;
  onToggleSidebar: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activePage,
  onNavigate,
  currentLanguage,
  isSidebarCollapsed,
  onToggleSidebar,
}) => {
  const t = translations[currentLanguage];

  const navItems = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { id: 'scanner', label: t.navScanner, icon: ScanLine },
    { id: 'batches', label: t.navBatches, icon: Boxes },
    { id: 'storage-checker', label: t.navStorageChecker, icon: ThermometerSnowflake },
    { id: 'sell-store', label: t.navSellVsStore, icon: Scale },
    { id: 'transport', label: t.navTransport, icon: Truck },
    { id: 'voice-advisor', label: t.navVoiceAdvisor, icon: BotMessageSquare },
    { id: 'settings', label: t.navSettings, icon: Settings },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={`hidden md:flex flex-col border-r border-emerald-950/10 liquid-glass transition-all duration-300 h-screen sticky top-0 z-40 select-none ${
          isSidebarCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        {/* Brand Area */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-emerald-950/10">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-800 to-green-900 text-white flex items-center justify-center shadow-md shrink-0">
              <Sprout className="w-6 h-6 text-lime-300" />
            </div>
            {!isSidebarCollapsed && (
              <div className="truncate">
                <span className="text-lg font-bold tracking-tight text-stone-900 block leading-tight">
                  AgroRescue
                </span>
                <span className="text-[11px] font-medium text-emerald-800 block truncate">
                  Post-Harvest AI
                </span>
              </div>
            )}
          </div>

          <button
            onClick={onToggleSidebar}
            className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-200/50 transition-colors focus-visible:outline-none"
            title={isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label="Toggle sidebar width"
          >
            {isSidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group text-left ${
                  isActive
                    ? 'bg-emerald-800 text-white shadow-sm'
                    : 'text-stone-700 hover:bg-emerald-50/80 hover:text-emerald-900'
                }`}
                title={isSidebarCollapsed ? item.label : undefined}
              >
                <Icon
                  className={`w-5 h-5 shrink-0 transition-colors ${
                    isActive ? 'text-lime-300' : 'text-stone-500 group-hover:text-emerald-700'
                  }`}
                />
                {!isSidebarCollapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </nav>

        {/* Quiet Environmental Indicator */}
        {!isSidebarCollapsed && (
          <div className="p-3 mx-3 mb-4 rounded-xl bg-emerald-900/5 border border-emerald-900/10 text-[11px] text-stone-600">
            <div className="font-semibold text-emerald-900">Cold Chain Guidance</div>
            <div className="mt-0.5 leading-snug">
              Keep breaker tomatoes at 10°–13°C. Avoid chilling injury &lt;10°C.
            </div>
          </div>
        )}
      </aside>

      {/* Mobile Bottom Navigation Bar (Core Quick Tabs) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 liquid-glass-elevated border-t border-emerald-950/10 px-2 py-1.5 flex items-center justify-around shadow-lg">
        {navItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center p-1.5 min-w-[54px] rounded-lg transition-colors ${
                isActive ? 'text-emerald-800 font-bold' : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-emerald-800' : 'text-stone-500'}`} />
              <span className="text-[10px] mt-0.5 truncate max-w-[64px]">{item.label}</span>
            </button>
          );
        })}
        {/* More tab for mobile */}
        <button
          onClick={() => onNavigate('voice-advisor')}
          className={`flex flex-col items-center justify-center p-1.5 min-w-[54px] rounded-lg transition-colors ${
            activePage === 'voice-advisor' ? 'text-emerald-800 font-bold' : 'text-stone-500'
          }`}
        >
          <BotMessageSquare className="w-5 h-5" />
          <span className="text-[10px] mt-0.5">{t.navVoiceAdvisor}</span>
        </button>
      </nav>
    </>
  );
};
