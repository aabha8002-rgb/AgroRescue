import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Bell,
  Globe,
  ChevronDown,
  Sparkles,
  Camera,
  PlusCircle,
  Calculator,
  X,
  AlertTriangle,
  Clock,
  CheckCircle2,
} from 'lucide-react';
import { Language, FarmerProfile } from '../types';
import { translations } from '../i18n/translations';
import { INITIAL_REMINDERS } from '../data/initialBatches';

interface TopHeaderProps {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  farmerProfile: FarmerProfile;
  onOpenVoiceModal: () => void;
  onNavigate: (page: string) => void;
  activePage: string;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  currentLanguage,
  onLanguageChange,
  farmerProfile,
  onOpenVoiceModal,
  onNavigate,
  activePage,
}) => {
  const t = translations[currentLanguage];
  const [showNotifications, setShowNotifications] = useState(false);
  const [showFarmMenu, setShowFarmMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const urgentCount = INITIAL_REMINDERS.filter((r) => r.type === 'urgent').length;

  return (
    <header className="sticky top-0 z-30 w-full liquid-glass border-b border-emerald-950/10 px-4 md:px-8 py-3.5 flex items-center justify-between gap-4">
      {/* Zone 1: Current Context & Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="relative">
          <button
            onClick={() => setShowFarmMenu(!showFarmMenu)}
            className="flex items-center gap-1.5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 rounded-md py-1 px-1.5"
            aria-label="Switch cluster location"
          >
            <div className="w-8 h-8 rounded-lg bg-emerald-800 text-white flex items-center justify-center font-bold text-sm shadow-sm shrink-0">
              AR
            </div>
            <div className="truncate">
              <span className="text-xs font-semibold uppercase tracking-wider text-emerald-800 block">
                {farmerProfile.district}
              </span>
              <span className="text-sm font-bold text-stone-900 group-hover:text-emerald-800 transition-colors flex items-center gap-1 truncate">
                {farmerProfile.farmName}
                <ChevronDown className="w-3.5 h-3.5 text-stone-500 shrink-0" />
              </span>
            </div>
          </button>

          {/* Farm Switcher Dropdown */}
          {showFarmMenu && (
            <div className="absolute left-0 mt-2 w-72 liquid-glass-elevated rounded-xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
              <div className="px-3 py-2 text-xs font-medium text-stone-500 border-b border-stone-200/60">
                Registered Farm Locations
              </div>
              <button
                onClick={() => setShowFarmMenu(false)}
                className="w-full text-left px-3 py-2.5 rounded-lg text-xs font-semibold text-emerald-950 bg-emerald-50/80 flex items-center justify-between mt-1"
              >
                <div>
                  <div className="font-bold">Sahyadri Kisan Agro Cluster</div>
                  <div className="text-stone-500 font-normal">Nashik, Dindori · 8.5 Acres (Active)</div>
                </div>
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              </button>
              <button
                onClick={() => {
                  setShowFarmMenu(false);
                  onNavigate('settings');
                }}
                className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-stone-700 hover:bg-stone-100 transition-colors mt-1"
              >
                + Register New Farm Location in Settings
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Zone 2: Fast Action Shortcuts (Desktop) */}
      <div className="hidden lg:flex items-center gap-2">
        <button
          onClick={() => onNavigate('scanner')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activePage === 'scanner'
              ? 'bg-emerald-800 text-white shadow-sm'
              : 'text-stone-700 bg-white/70 hover:bg-emerald-50 hover:text-emerald-900 border border-stone-200/70'
          }`}
        >
          <Camera className="w-3.5 h-3.5 text-emerald-600" />
          <span>{t.quickScan}</span>
        </button>

        <button
          onClick={() => onNavigate('batches')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activePage === 'batches'
              ? 'bg-emerald-800 text-white shadow-sm'
              : 'text-stone-700 bg-white/70 hover:bg-emerald-50 hover:text-emerald-900 border border-stone-200/70'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5 text-emerald-600" />
          <span>{t.quickAddBatch}</span>
        </button>

        <button
          onClick={() => onNavigate('sell-store')}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
            activePage === 'sell-store'
              ? 'bg-emerald-800 text-white shadow-sm'
              : 'text-stone-700 bg-white/70 hover:bg-emerald-50 hover:text-emerald-900 border border-stone-200/70'
          }`}
        >
          <Calculator className="w-3.5 h-3.5 text-emerald-600" />
          <span>{t.quickCompare}</span>
        </button>
      </div>

      {/* Zone 3: Voice Mic Button, Notifications, & Language Switcher */}
      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {/* Voice Assistant Header Trigger Button */}
        <button
          onClick={onOpenVoiceModal}
          className="relative flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-700 hover:to-teal-700 rounded-lg shadow-sm transition-transform active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 shrink-0"
          title={t.voiceAssistant}
        >
          <Mic className="w-3.5 h-3.5 text-lime-300" />
          <span className="hidden sm:inline">{t.voiceAssistant}</span>
        </button>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-9 h-9 rounded-lg bg-white/80 hover:bg-stone-100 border border-stone-200/80 flex items-center justify-center text-stone-700 transition-colors relative"
            aria-label="Toggle notifications"
          >
            <Bell className="w-4 h-4 text-stone-700" />
            {urgentCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-600 text-white font-mono text-[10px] flex items-center justify-center font-bold">
                {urgentCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 liquid-glass-elevated rounded-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-150 shadow-xl">
              <div className="flex items-center justify-between px-2 pb-2 border-b border-stone-200/80">
                <span className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-emerald-700" />
                  {t.remindersTitle}
                </span>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="p-1 text-stone-400 hover:text-stone-700 rounded-md"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-stone-100 max-h-72 overflow-y-auto mt-1">
                {INITIAL_REMINDERS.map((rem) => (
                  <div key={rem.id} className="p-2.5 hover:bg-stone-50/80 rounded-lg transition-colors text-left">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-bold text-stone-900 flex items-center gap-1">
                        {rem.type === 'urgent' ? (
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        )}
                        {rem.title}
                      </span>
                      <span className="text-[11px] font-mono text-stone-500 shrink-0">{rem.due}</span>
                    </div>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed">{rem.description}</p>
                  </div>
                ))}
              </div>

              <div className="mt-2 pt-2 border-t border-stone-200/60 text-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    onNavigate('batches');
                  }}
                  className="text-xs font-semibold text-emerald-800 hover:text-emerald-950"
                >
                  {t.viewAllBatches} &rarr;
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Regional Language Selector */}
        <div className="relative">
          <button
            onClick={() => setShowLangMenu(!showLangMenu)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/80 hover:bg-stone-100 border border-stone-200/80 text-xs font-semibold text-stone-800 transition-colors"
            aria-label="Select language"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-700" />
            <span className="font-medium">
              {currentLanguage === 'en' ? 'English' : currentLanguage === 'hi' ? 'हिन्दी' : 'मराठी'}
            </span>
            <ChevronDown className="w-3 h-3 text-stone-500" />
          </button>

          {showLangMenu && (
            <div className="absolute right-0 mt-2 w-36 liquid-glass-elevated rounded-xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 shadow-lg">
              <button
                onClick={() => {
                  onLanguageChange('en');
                  setShowLangMenu(false);
                }}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  currentLanguage === 'en' ? 'bg-emerald-800 text-white font-bold' : 'text-stone-800 hover:bg-stone-100'
                }`}
              >
                English
              </button>
              <button
                onClick={() => {
                  onLanguageChange('hi');
                  setShowLangMenu(false);
                }}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  currentLanguage === 'hi' ? 'bg-emerald-800 text-white font-bold' : 'text-stone-800 hover:bg-stone-100'
                }`}
              >
                हिन्दी (Hindi)
              </button>
              <button
                onClick={() => {
                  onLanguageChange('mr');
                  setShowLangMenu(false);
                }}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  currentLanguage === 'mr' ? 'bg-emerald-800 text-white font-bold' : 'text-stone-800 hover:bg-stone-100'
                }`}
              >
                मराठी (Marathi)
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
