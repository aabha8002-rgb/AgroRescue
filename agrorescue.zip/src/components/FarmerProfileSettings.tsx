import React, { useState } from 'react';
import {
  Settings,
  User,
  MapPin,
  Globe,
  RotateCcw,
  CheckCircle2,
  Save,
  Building2,
  ThermometerSnowflake,
  Shield,
  Layers,
} from 'lucide-react';
import { FarmerProfile, Language, CropType } from '../types';
import { translations } from '../i18n/translations';

interface FarmerProfileSettingsProps {
  profile: FarmerProfile;
  currentLanguage: Language;
  onUpdateProfile: (updated: FarmerProfile) => void;
  onLanguageChange: (lang: Language) => void;
  onResetDemoData: () => void;
}

export const FarmerProfileSettings: React.FC<FarmerProfileSettingsProps> = ({
  profile,
  currentLanguage,
  onUpdateProfile,
  onLanguageChange,
  onResetDemoData,
}) => {
  const t = translations[currentLanguage];

  const [formData, setFormData] = useState<FarmerProfile>(profile);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    onLanguageChange(formData.selectedLanguage);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="liquid-glass rounded-2xl p-5">
        <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
          {t.settingsTitle}
        </h1>
        <p className="text-xs text-stone-600 mt-1 leading-relaxed">
          Configure farm parameters, cold storage logistics, APMC mandi auction defaults, and app language.
        </p>
      </div>

      {saveSuccess && (
        <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="font-semibold">{t.profileSaved}</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Profile Card */}
        <div className="liquid-glass rounded-2xl p-6">
          <div className="flex flex-col sm:flex-row items-center gap-5 pb-6 border-b border-stone-200">
            <img
              src="/src/assets/images/farmer_profile_portrait_1792809676944.jpg"
              alt="Farmer Profile"
              className="w-20 h-20 rounded-2xl object-cover border-2 border-emerald-800 shadow-md shrink-0"
            />
            <div className="text-center sm:text-left">
              <h2 className="text-base font-bold text-stone-900">{profile.name}</h2>
              <p className="text-xs text-stone-500 mt-0.5">
                {profile.farmName} · {profile.district}, {profile.state}
              </p>
              <div className="flex items-center gap-2 mt-2 justify-center sm:justify-start text-xs font-semibold text-emerald-800">
                <span className="px-2.5 py-0.5 rounded-md bg-emerald-50 border border-emerald-200">
                  {profile.totalFarmAreaAcres} Acres
                </span>
                <span className="px-2.5 py-0.5 rounded-md bg-stone-100 border border-stone-200">
                  Primary: {profile.primaryCrop}
                </span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6 text-xs">
            <div>
              <label className="font-bold text-stone-800 block mb-1.5">{t.farmerName}</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900 font-semibold"
                required
              />
            </div>

            <div>
              <label className="font-bold text-stone-800 block mb-1.5">{t.farmName}</label>
              <input
                type="text"
                value={formData.farmName}
                onChange={(e) => setFormData({ ...formData, farmName: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900 font-semibold"
                required
              />
            </div>

            <div>
              <label className="font-bold text-stone-800 block mb-1.5">{t.districtState}</label>
              <input
                type="text"
                value={formData.district}
                onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900"
                required
              />
            </div>

            <div>
              <label className="font-bold text-stone-800 block mb-1.5">{t.primaryCrops}</label>
              <select
                value={formData.primaryCrop}
                onChange={(e) => setFormData({ ...formData, primaryCrop: e.target.value as CropType })}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900 font-semibold"
              >
                <option value="Tomato">Tomato (टमाटर / टोमॅटो)</option>
                <option value="Onion">Onion (प्याज / कांदा)</option>
                <option value="Potato">Potato (आलू / बटाटा)</option>
                <option value="Capsicum">Capsicum (शिमला मिर्च / ढोबळी मिरची)</option>
                <option value="Green Chilli">Green Chilli (हरी मिर्च)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Cold Storage & Mandi Logistics Card */}
        <div className="liquid-glass rounded-2xl p-6 space-y-4">
          <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-200 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-800" />
            Market &amp; Cold Storage Logistics
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-bold text-stone-800 block mb-1.5">{t.nearestMandi}</label>
              <input
                type="text"
                value={formData.nearestApmcMandi}
                onChange={(e) => setFormData({ ...formData, nearestApmcMandi: e.target.value })}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900"
                required
              />
            </div>

            <div>
              <label className="font-bold text-stone-800 block mb-1.5">{t.coldStoreDistance}</label>
              <input
                type="number"
                value={formData.nearestColdStoreKm}
                onChange={(e) => setFormData({ ...formData, nearestColdStoreKm: Number(e.target.value) })}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                required
              />
            </div>
          </div>
        </div>

        {/* Regional Language & Preferences */}
        <div className="liquid-glass rounded-2xl p-6 space-y-4">
          <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-200 flex items-center gap-2">
            <Globe className="w-4 h-4 text-emerald-800" />
            Language Preference &amp; Regional Localization
          </h2>

          <div className="max-w-xs text-xs">
            <label className="font-bold text-stone-800 block mb-1.5">{t.appLanguage}</label>
            <select
              value={formData.selectedLanguage}
              onChange={(e) => setFormData({ ...formData, selectedLanguage: e.target.value as Language })}
              className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-stone-900 font-semibold"
            >
              <option value="en">English</option>
              <option value="hi">हिन्दी (Hindi)</option>
              <option value="mr">मराठी (Marathi)</option>
            </select>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <button
            type="button"
            onClick={onResetDemoData}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-rose-700 bg-white hover:bg-rose-50 border border-rose-200 rounded-xl transition-colors shadow-sm"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.resetDemoData}</span>
          </button>

          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-emerald-800 hover:bg-emerald-900 rounded-xl shadow-md transition-all active:scale-95"
          >
            <Save className="w-4 h-4 text-lime-300" />
            <span>{t.saveProfile}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
