import React, { useState, useMemo } from 'react';
import {
  Truck,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ChevronRight,
  Info,
  Layers,
  ThermometerSnowflake,
} from 'lucide-react';
import { Language, TransportInputs, TransportResult, VehicleOption } from '../types';
import { translations } from '../i18n/translations';
import { POPULAR_VEHICLES } from '../data/cropKnowledge';

interface TransportOptimizerProps {
  currentLanguage: Language;
}

export const TransportOptimizer: React.FC<TransportOptimizerProps> = ({
  currentLanguage,
}) => {
  const t = translations[currentLanguage];

  const [inputs, setInputs] = useState<TransportInputs>({
    quantityKg: 2400,
    distanceKm: 38, // Nashik farm to APMC or cold store
    selectedVehicleId: 'bolero-pickup',
    produceShelfLifeDays: 2.5,
    estimatedTransitHours: 3.5,
    dieselFuelRateInrPerLitre: 94,
  });

  const selectedVehicle = POPULAR_VEHICLES.find((v) => v.id === inputs.selectedVehicleId) || POPULAR_VEHICLES[1];

  const result: TransportResult = useMemo(() => {
    const { quantityKg, distanceKm, produceShelfLifeDays, estimatedTransitHours } = inputs;
    const vehicle = selectedVehicle;

    // Number of trips
    const tripsRequired = Math.ceil(quantityKg / vehicle.capacityKg);
    const roundTripDistancePerTrip = distanceKm * 2;
    const totalDistanceKm = tripsRequired * roundTripDistancePerTrip;

    // Fuel and vehicle hiring cost
    const fuelAndVehicleCostInr = totalDistanceKm * vehicle.ratePerKmInr;
    const loadingUnloadingCostInr = tripsRequired * vehicle.baseLoadingFeeInr;
    const totalCostInr = fuelAndVehicleCostInr + loadingUnloadingCostInr;
    const costPerKgInr = quantityKg > 0 ? totalCostInr / quantityKg : 0;

    // Transit spoilage risk evaluation
    let transitSpoilageRisk: 'Low' | 'Moderate' | 'High' = 'Low';
    let riskExplanation = '';
    const mitigationTips: string[] = [];

    if (!vehicle.isRefrigerated) {
      if (produceShelfLifeDays <= 2.0 && estimatedTransitHours >= 3.0) {
        transitSpoilageRisk = 'High';
        riskExplanation = `Produce has only ${produceShelfLifeDays} days of shelf life. An unventilated transit of ${estimatedTransitHours} hours under hot daylight (>32°C) causes internal crate heat build-up and rapid bacterial breakdown.`;
        mitigationTips.push('Schedule departure at night or before 5:00 AM to avoid direct solar baking of crates.');
        mitigationTips.push('Ensure top tarpaulin is tented with 20cm air gaps; never tightly seal ripening tomatoes under black plastic.');
        mitigationTips.push('Consider upgrading to an Insulated Reefer Van if transport distance exceeds 100km.');
      } else if (estimatedTransitHours > vehicle.maxTripHoursRecommended) {
        transitSpoilageRisk = 'Moderate';
        riskExplanation = `Transit duration exceeds the recommended ${vehicle.maxTripHoursRecommended} hours for this open carrier. Vibration and road heat may cause skin abrasion.`;
        mitigationTips.push('Use cardboard crate liners or corrugated cushioning at the bottom layer.');
        mitigationTips.push('Avoid overloading beyond vehicle rated capacity to prevent tier crushing.');
      } else {
        transitSpoilageRisk = 'Low';
        riskExplanation = `Transit duration is within safe thresholds. Produce condition is suitable for standard ventilated transport.`;
        mitigationTips.push('Stack crates interlocking securely with nylon tie ropes.');
        mitigationTips.push('Provide shade during loading and unloading at Mandi gate.');
      }
    } else {
      transitSpoilageRisk = 'Low';
      riskExplanation = `Insulated cold-chain carrier maintains 10°C–12°C. Near zero in-transit spoilage risk.`;
      mitigationTips.push('Pre-cool carrier chamber 30 minutes before loading.');
    }

    return {
      vehicle,
      tripsRequired,
      totalDistanceKm,
      fuelAndVehicleCostInr,
      loadingUnloadingCostInr,
      totalCostInr,
      costPerKgInr,
      transitSpoilageRisk,
      riskExplanation,
      mitigationTips,
    };
  }, [inputs, selectedVehicle]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="liquid-glass rounded-2xl p-5">
        <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
          {t.transportTitle}
        </h1>
        <p className="text-xs text-stone-600 mt-1 max-w-2xl leading-relaxed">
          {t.transportSubtitle}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs */}
        <div className="lg:col-span-5 space-y-4">
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-200">
              Cargo &amp; Route Configuration
            </h2>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-bold text-stone-800 block mb-1">
                  {t.batchVolumeKg}
                </label>
                <input
                  type="number"
                  value={inputs.quantityKg}
                  onChange={(e) => setInputs({ ...inputs, quantityKg: Math.max(0, Number(e.target.value)) })}
                  className="w-full p-2.5 rounded-xl bg-white border border-stone-200 font-mono font-bold text-stone-900"
                />
              </div>

              <div>
                <label className="font-bold text-stone-800 block mb-1">
                  {t.distanceToMarketKm}
                </label>
                <input
                  type="number"
                  value={inputs.distanceKm}
                  onChange={(e) => setInputs({ ...inputs, distanceKm: Math.max(1, Number(e.target.value)) })}
                  className="w-full p-2.5 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                />
              </div>
            </div>

            {/* Produce Shelf Life & Transit Hours */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="font-bold text-stone-800 block mb-1">
                  Shelf Life Remaining
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={inputs.produceShelfLifeDays}
                    onChange={(e) => setInputs({ ...inputs, produceShelfLifeDays: Math.max(0.5, Number(e.target.value)) })}
                    className="w-full p-2.5 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 text-[11px]">days</span>
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-800 block mb-1">
                  Est. Transit Duration
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    value={inputs.estimatedTransitHours}
                    onChange={(e) => setInputs({ ...inputs, estimatedTransitHours: Math.max(0.5, Number(e.target.value)) })}
                    className="w-full p-2.5 rounded-xl bg-white border border-stone-200 font-mono text-stone-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 text-[11px]">hours</span>
                </div>
              </div>
            </div>

            {/* Select Vehicle Carrier */}
            <div>
              <label className="font-bold text-stone-800 block mb-1.5">
                {t.selectVehicle}
              </label>
              <div className="space-y-2">
                {POPULAR_VEHICLES.map((veh) => {
                  const isSelected = veh.id === inputs.selectedVehicleId;
                  const trips = Math.ceil(inputs.quantityKg / veh.capacityKg);
                  return (
                    <button
                      key={veh.id}
                      type="button"
                      onClick={() => setInputs({ ...inputs, selectedVehicleId: veh.id })}
                      className={`w-full p-3 rounded-xl border text-left flex items-center justify-between text-xs transition-all ${
                        isSelected
                          ? 'border-emerald-800 bg-emerald-50/80 shadow-sm'
                          : 'border-stone-200 bg-white hover:bg-stone-50'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-stone-900 flex items-center gap-1.5">
                          <Truck className="w-4 h-4 text-emerald-800 shrink-0" />
                          {veh.name} ({veh.localName})
                        </div>
                        <div className="text-[11px] text-stone-500 mt-0.5">
                          Capacity: {veh.capacityKg.toLocaleString()} kg · ₹{veh.ratePerKmInr}/km · Base: ₹{veh.baseLoadingFeeInr}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-mono font-bold text-emerald-900 text-xs">
                          {trips} {trips === 1 ? 'trip' : 'trips'}
                        </span>
                        {veh.isRefrigerated && (
                          <span className="text-[10px] text-teal-700 block font-semibold">
                            Chilled Reefer
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Right Logistics Economics & Spoilage Alert */}
        <div className="lg:col-span-7 space-y-4">
          {/* Spoilage Risk Warning Banner */}
          <div
            className={`liquid-glass rounded-2xl p-5 border-2 ${
              result.transitSpoilageRisk === 'High'
                ? 'border-rose-500 bg-rose-50/70 text-rose-950'
                : result.transitSpoilageRisk === 'Moderate'
                ? 'border-amber-500 bg-amber-50/70 text-amber-950'
                : 'border-emerald-600 bg-emerald-50/70 text-emerald-950'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-white shadow-sm shrink-0">
                {result.transitSpoilageRisk === 'High' ? (
                  <AlertTriangle className="w-6 h-6 text-rose-600" />
                ) : result.transitSpoilageRisk === 'Moderate' ? (
                  <Clock className="w-6 h-6 text-amber-600" />
                ) : (
                  <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                )}
              </div>
              <div>
                <span className="text-xs font-bold uppercase tracking-wider block">
                  {result.transitSpoilageRisk === 'High'
                    ? t.riskHigh
                    : result.transitSpoilageRisk === 'Moderate'
                    ? t.riskModerate
                    : t.riskLow}
                </span>
                <p className="text-xs mt-1 leading-relaxed opacity-90">
                  {result.riskExplanation}
                </p>
              </div>
            </div>

            {/* Mitigation Tips */}
            {result.mitigationTips.length > 0 && (
              <div className="mt-4 pt-3 border-t border-current/15">
                <span className="text-xs font-bold block mb-1.5">
                  {t.mitigationTipsTitle}:
                </span>
                <ul className="space-y-1 text-xs opacity-90">
                  {result.mitigationTips.map((tip, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-700 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Transport Fleet Cost Breakdown */}
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            <h2 className="text-xs font-bold text-stone-900 uppercase tracking-wider pb-2 border-b border-stone-200">
              Trip Economics &amp; Unit Cost
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">{t.totalTrips}</span>
                <span className="text-2xl font-mono font-bold text-stone-900">
                  {result.tripsRequired}
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5">
                  Roundtrip: {result.totalDistanceKm} km
                </span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">Fuel &amp; Hire</span>
                <span className="text-2xl font-mono font-bold text-stone-900 tabular-nums">
                  ₹{Math.round(result.fuelAndVehicleCostInr).toLocaleString()}
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5">
                  @ ₹{selectedVehicle.ratePerKmInr}/km
                </span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">Loading Labour</span>
                <span className="text-2xl font-mono font-bold text-stone-900 tabular-nums">
                  ₹{result.loadingUnloadingCostInr.toLocaleString()}
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5">
                  Hamaali &amp; dock
                </span>
              </div>

              <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200">
                <span className="text-emerald-900 font-bold block text-[11px]">{t.costPerKg}</span>
                <span className="text-2xl font-mono font-extrabold text-emerald-900 tabular-nums">
                  ₹{result.costPerKgInr.toFixed(2)}
                </span>
                <span className="text-[10px] text-emerald-800 block mt-0.5">
                  per kg transported
                </span>
              </div>
            </div>

            {/* Total Transport Expense Box */}
            <div className="p-4 rounded-xl bg-stone-900 text-white flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-stone-300 block">
                  {t.totalCost} (Estimated APMC Mandi Delivery)
                </span>
                <span className="text-[11px] text-stone-400 mt-0.5 block">
                  Includes {result.tripsRequired} round trips for {inputs.quantityKg.toLocaleString()} kg using {selectedVehicle.name}
                </span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black font-mono text-lime-300 tabular-nums">
                  ₹{Math.round(result.totalCostInr).toLocaleString()}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-600 leading-relaxed">
              <strong>Fleet Recommendation:</strong> If moving &gt;3,000 kg, choosing an <strong className="text-stone-900">Eicher 14ft</strong> reduces freight cost from ₹1.45/kg down to ₹0.95/kg by avoiding multiple small-vehicle turnarounds.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
