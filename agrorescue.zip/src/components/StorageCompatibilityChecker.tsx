import React, { useState } from 'react';
import {
  ThermometerSnowflake,
  AlertTriangle,
  CheckCircle2,
  Info,
  ShieldAlert,
  Wind,
  Droplets,
  Layers,
  ChevronRight,
  Plus,
  X,
} from 'lucide-react';
import { CropType, Language } from '../types';
import { translations } from '../i18n/translations';
import { CROP_STORAGE_DATABASE } from '../data/cropKnowledge';

interface StorageCompatibilityCheckerProps {
  currentLanguage: Language;
}

export const StorageCompatibilityChecker: React.FC<StorageCompatibilityCheckerProps> = ({
  currentLanguage,
}) => {
  const t = translations[currentLanguage];

  const [primaryCrop, setPrimaryCrop] = useState<CropType>('Tomato');
  const [coStorageCrops, setCoStorageCrops] = useState<CropType[]>(['Onion']);
  const [storageDurationDays, setStorageDurationDays] = useState<number>(14);
  const [facilityType, setFacilityType] = useState<string>('Standard Cold Storage');

  const primaryProfile = CROP_STORAGE_DATABASE[primaryCrop];

  // Evaluate compatibility conflicts between primaryCrop and selected co-storage crops
  const conflicts: {
    cropA: CropType;
    cropB: CropType;
    severity: 'Incompatible' | 'Warning';
    reason: string;
  }[] = [];

  coStorageCrops.forEach((otherCrop) => {
    // Check primary incompatibilities
    const matchIncompat = primaryProfile.incompatibleCrops.find((i) => i.crop === otherCrop);
    if (matchIncompat) {
      conflicts.push({
        cropA: primaryCrop,
        cropB: otherCrop,
        severity: 'Incompatible',
        reason: matchIncompat.reason,
      });
    }

    // Check temperature & humidity divergence
    const otherProfile = CROP_STORAGE_DATABASE[otherCrop];
    if (otherProfile) {
      const tempOverlap =
        Math.max(primaryProfile.optimalTempMinC, otherProfile.optimalTempMinC) <=
        Math.min(primaryProfile.optimalTempMaxC, otherProfile.optimalTempMaxC);

      const humidityOverlap =
        Math.max(primaryProfile.optimalHumidityMinRh, otherProfile.optimalHumidityMinRh) <=
        Math.min(primaryProfile.optimalHumidityMaxRh, otherProfile.optimalHumidityMaxRh);

      if (!tempOverlap && !matchIncompat) {
        conflicts.push({
          cropA: primaryCrop,
          cropB: otherCrop,
          severity: 'Warning',
          reason: `Temperature conflict: ${primaryCrop} requires ${primaryProfile.optimalTempMinC}–${primaryProfile.optimalTempMaxC}°C, but ${otherCrop} requires ${otherProfile.optimalTempMinC}–${otherProfile.optimalTempMaxC}°C.`,
        });
      }

      if (!humidityOverlap && !matchIncompat) {
        conflicts.push({
          cropA: primaryCrop,
          cropB: otherCrop,
          severity: 'Warning',
          reason: `Humidity conflict: ${primaryCrop} needs ${primaryProfile.optimalHumidityMinRh}–${primaryProfile.optimalHumidityMaxRh}% RH, while ${otherCrop} requires ${otherProfile.optimalHumidityMinRh}–${otherProfile.optimalHumidityMaxRh}% RH.`,
        });
      }
    }
  });

  const isCoStorageIncompatible = conflicts.some((c) => c.severity === 'Incompatible');
  const isCoStorageWarning = conflicts.some((c) => c.severity === 'Warning');

  const handleAddCoStorage = (crop: CropType) => {
    if (crop !== primaryCrop && !coStorageCrops.includes(crop) && coStorageCrops.length < 3) {
      setCoStorageCrops([...coStorageCrops, crop]);
    }
  };

  const handleRemoveCoStorage = (crop: CropType) => {
    setCoStorageCrops(coStorageCrops.filter((c) => c !== crop));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="liquid-glass rounded-2xl p-5">
        <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
          {t.storageCheckerTitle}
        </h1>
        <p className="text-xs text-stone-600 mt-1 max-w-2xl leading-relaxed">
          {t.storageCheckerSubtitle}
        </p>
      </div>

      {/* Configuration Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Produce Selection & Duration */}
        <div className="lg:col-span-5 space-y-4">
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            <h2 className="text-sm font-bold text-stone-900 pb-2 border-b border-stone-200">
              Storage Chamber Setup
            </h2>

            {/* Primary Crop */}
            <div>
              <label className="text-xs font-bold text-stone-800 block mb-1">
                {t.primaryCrop}
              </label>
              <select
                value={primaryCrop}
                onChange={(e) => {
                  const newCrop = e.target.value as CropType;
                  setPrimaryCrop(newCrop);
                  setCoStorageCrops(coStorageCrops.filter((c) => c !== newCrop));
                }}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-xs font-semibold text-stone-900 focus:ring-2 focus:ring-emerald-700"
              >
                {Object.keys(CROP_STORAGE_DATABASE).map((crop) => (
                  <option key={crop} value={crop}>
                    {crop} ({CROP_STORAGE_DATABASE[crop as CropType].commonNameHi} / {CROP_STORAGE_DATABASE[crop as CropType].commonNameMr})
                  </option>
                ))}
              </select>
            </div>

            {/* Co-Storage Produce List */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-stone-800">
                  {t.addCoStorageCrop} (Max 3)
                </label>
                <span className="text-[11px] text-stone-500">Same room / shed</span>
              </div>

              {/* Added Co-Storage Pills */}
              <div className="flex flex-wrap gap-2 mb-2">
                {coStorageCrops.map((c) => (
                  <span
                    key={c}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-100/70 text-emerald-900 text-xs font-semibold border border-emerald-200"
                  >
                    {c}
                    <button
                      type="button"
                      onClick={() => handleRemoveCoStorage(c)}
                      className="text-emerald-700 hover:text-emerald-950 ml-1"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
                {coStorageCrops.length === 0 && (
                  <span className="text-xs text-stone-400 italic">
                    Single-crop storage selected (isolated chamber).
                  </span>
                )}
              </div>

              {/* Add dropdown */}
              {coStorageCrops.length < 3 && (
                <div className="flex items-center gap-2">
                  <select
                    id="coStorageAddSelect"
                    defaultValue=""
                    onChange={(e) => {
                      if (e.target.value) {
                        handleAddCoStorage(e.target.value as CropType);
                        e.target.value = '';
                      }
                    }}
                    className="w-full p-2 text-xs rounded-xl bg-white border border-stone-200 text-stone-700 font-medium"
                  >
                    <option value="" disabled>
                      + Add another crop to test co-storage...
                    </option>
                    {Object.keys(CROP_STORAGE_DATABASE)
                      .filter((c) => c !== primaryCrop && !coStorageCrops.includes(c as CropType))
                      .map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                  </select>
                </div>
              )}
            </div>

            {/* Storage Duration Slider */}
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-stone-800 mb-1">
                <span>{t.storageDuration}</span>
                <span className="font-mono text-emerald-800">{storageDurationDays} days</span>
              </div>
              <input
                type="range"
                min="1"
                max="60"
                value={storageDurationDays}
                onChange={(e) => setStorageDurationDays(Number(e.target.value))}
                className="w-full accent-emerald-800 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-stone-400 font-mono mt-0.5">
                <span>1 day (transit)</span>
                <span>15 days (mid hold)</span>
                <span>60 days (extended)</span>
              </div>
            </div>

            {/* Facility Choice */}
            <div>
              <label className="text-xs font-bold text-stone-800 block mb-1">
                Storage Facility Type
              </label>
              <select
                value={facilityType}
                onChange={(e) => setFacilityType(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-white border border-stone-200 text-xs font-semibold text-stone-900"
              >
                <option value="Standard Cold Storage">Commercial Cold Storage (Chilled Chamber)</option>
                <option value="Evaporative Cool Chamber">Zero Energy Cool Chamber (ZECC / Rural)</option>
                <option value="Ventilated Farm Shed">Traditional Ventilated Shaded Shed / Chawl</option>
                <option value="Modified Atmosphere Packaging">MAP Cold Chain Room</option>
              </select>
            </div>
          </div>

          {/* Missing Information Verification Checklist */}
          <div className="liquid-glass rounded-2xl p-5 border-amber-200/60 bg-amber-50/20">
            <h3 className="text-xs font-bold text-amber-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-amber-700" />
              {t.missingInfoChecklistTitle}
            </h3>
            <ul className="space-y-2 text-xs text-stone-700">
              {primaryProfile.missingInfoChecklist.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Right Area: Compatibility Assessment & Storage Matrix */}
        <div className="lg:col-span-7 space-y-4">
          {/* Compatibility Verdict Banner */}
          <div
            className={`liquid-glass rounded-2xl p-5 border-2 ${
              isCoStorageIncompatible
                ? 'border-rose-500 bg-rose-50/60 text-rose-950'
                : isCoStorageWarning
                ? 'border-amber-500 bg-amber-50/60 text-amber-950'
                : 'border-emerald-600 bg-emerald-50/60 text-emerald-950'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-white shadow-sm shrink-0">
                {isCoStorageIncompatible ? (
                  <ShieldAlert className="w-7 h-7 text-rose-600" />
                ) : isCoStorageWarning ? (
                  <AlertTriangle className="w-7 h-7 text-amber-600" />
                ) : (
                  <CheckCircle2 className="w-7 h-7 text-emerald-600" />
                )}
              </div>

              <div>
                <h2 className="text-base font-extrabold tracking-tight">
                  {isCoStorageIncompatible
                    ? t.compatIncompatible
                    : isCoStorageWarning
                    ? t.compatWarning
                    : t.compatSafe}
                </h2>
                <p className="text-xs mt-1 leading-relaxed opacity-90">
                  {isCoStorageIncompatible
                    ? 'Cross-storage will cause immediate accelerated rot, physiological breakdown, or ethylene poisoning within 48 hours.'
                    : isCoStorageWarning
                    ? 'Temperature or humidity ranges conflict. Separate into different bays or adjust set points with caution.'
                    : 'Storage requirements align favorably. Maintain adequate circulation spacing between crates.'}
                </p>
              </div>
            </div>

            {/* List Conflicts */}
            {conflicts.length > 0 && (
              <div className="mt-4 pt-3 border-t border-current/15 space-y-2 text-xs">
                {conflicts.map((conf, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-white/80 border border-current/20">
                    <span className="font-bold block">
                      Conflict: {conf.cropA} + {conf.cropB} ({conf.severity})
                    </span>
                    <p className="text-[11px] mt-0.5 opacity-90 leading-relaxed">
                      {conf.reason}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Primary Crop Scientific Storage Guidance Card */}
          <div className="liquid-glass rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h2 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                <ThermometerSnowflake className="w-4 h-4 text-emerald-700" />
                Recommended Storage Parameters: {primaryCrop}
              </h2>
              <span className="text-xs font-mono font-semibold text-stone-500">
                Curated Agronomy Data
              </span>
            </div>

            {/* Matrix of parameters */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">{t.tempRange}</span>
                <span className="text-base font-mono font-bold text-emerald-900">
                  {primaryProfile.optimalTempMinC}°C – {primaryProfile.optimalTempMaxC}°C
                </span>
                {primaryProfile.chillingInjuryThresholdC !== null && (
                  <span className="text-[10px] text-rose-600 block mt-0.5">
                    Chilling injury &lt; {primaryProfile.chillingInjuryThresholdC}°C
                  </span>
                )}
              </div>

              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">{t.humidityRange}</span>
                <span className="text-base font-mono font-bold text-emerald-900">
                  {primaryProfile.optimalHumidityMinRh}% – {primaryProfile.optimalHumidityMaxRh}%
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5">Relative Humidity</span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">Ethylene Production</span>
                <span className="text-base font-bold text-stone-900">
                  {primaryProfile.ethyleneProduction}
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5">
                  Sensitivity: {primaryProfile.ethyleneSensitivity}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-500 block text-[11px]">Cold vs Ambient Life</span>
                <span className="text-base font-mono font-bold text-stone-900">
                  {primaryProfile.coldStorageShelfLifeDays}d <span className="text-xs text-stone-400">/ {primaryProfile.ambientShelfLifeDays}d</span>
                </span>
                <span className="text-[10px] text-stone-500 block mt-0.5">Max potential</span>
              </div>
            </div>

            {/* Critical Storage Precautions */}
            <div className="pt-2">
              <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider mb-2">
                {t.precautionsTitle}
              </h3>
              <div className="space-y-2 text-xs">
                {primaryProfile.criticalPrecautions.map((prec, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-stone-700 leading-relaxed flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 mt-0.5 shrink-0" />
                    <span>{prec}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
