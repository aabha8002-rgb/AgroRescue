import React, { useState } from 'react';
import {
  Boxes,
  Plus,
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Layers,
  Calendar,
  MapPin,
  X,
  ChevronDown,
  Info,
} from 'lucide-react';
import { HarvestBatch, CropType, BatchRiskLevel, BatchGrade, Language } from '../types';
import { translations } from '../i18n/translations';

interface HarvestBatchManagerProps {
  batches: HarvestBatch[];
  currentLanguage: Language;
  onAddBatch: (batch: HarvestBatch) => void;
  onUpdateBatch: (batch: HarvestBatch) => void;
  onDeleteBatch: (id: string) => void;
  selectedBatchForInspection?: HarvestBatch | null;
  onCloseInspectionModal?: () => void;
}

export const HarvestBatchManager: React.FC<HarvestBatchManagerProps> = ({
  batches,
  currentLanguage,
  onAddBatch,
  onUpdateBatch,
  onDeleteBatch,
  selectedBatchForInspection,
  onCloseInspectionModal,
}) => {
  const t = translations[currentLanguage];

  const [searchTerm, setSearchTerm] = useState('');
  const [cropFilter, setCropFilter] = useState<string>('All');
  const [riskFilter, setRiskFilter] = useState<string>('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingBatch, setEditingBatch] = useState<HarvestBatch | null>(null);
  const [viewingBatch, setViewingBatch] = useState<HarvestBatch | null>(selectedBatchForInspection || null);

  // New batch form state
  const [newBatch, setNewBatch] = useState<Partial<HarvestBatch>>({
    crop: 'Tomato',
    variety: 'Nashik Hybrid Selection',
    quantityKg: 2000,
    initialQuantityKg: 2000,
    harvestDate: new Date().toISOString().split('T')[0],
    grade: 'Grade B+',
    riskLevel: 'Warning',
    storageType: 'Ventilated Crates',
    location: 'Packing Bay A, Block 3',
    currentFreshnessScore: 78,
    estimatedShelfLifeAmbientDays: 4,
    estimatedShelfLifeColdDays: 16,
    estimatedMarketValueInr: 36000,
    notes: 'Normal morning harvest in ventilated plastic crates.',
    isDemoData: false,
  });

  // Filter batches
  const filteredBatches = batches.filter((b) => {
    const matchesSearch =
      b.batchCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.variety.toLowerCase().includes(searchTerm.toLowerCase()) ||
      b.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCrop = cropFilter === 'All' || b.crop === cropFilter;
    const matchesRisk = riskFilter === 'All' || b.riskLevel === riskFilter;
    return matchesSearch && matchesCrop && matchesRisk;
  });

  const handleSaveNewBatch = (e: React.FormEvent) => {
    e.preventDefault();
    const batchId = `batch-${Date.now()}`;
    const code = `NSK-${newBatch.crop?.substring(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`;

    const created: HarvestBatch = {
      id: batchId,
      batchCode: code,
      crop: (newBatch.crop as CropType) || 'Tomato',
      variety: newBatch.variety || 'Standard Hybrid',
      harvestDate: newBatch.harvestDate || new Date().toISOString().split('T')[0],
      quantityKg: Number(newBatch.quantityKg) || 1000,
      initialQuantityKg: Number(newBatch.quantityKg) || 1000,
      currentFreshnessScore: Number(newBatch.currentFreshnessScore) || 75,
      grade: (newBatch.grade as BatchGrade) || 'Grade B+',
      riskLevel: (newBatch.riskLevel as BatchRiskLevel) || 'Warning',
      storageType: newBatch.storageType || 'Ventilated Crates',
      location: newBatch.location || 'Farm Shed',
      estimatedShelfLifeAmbientDays: Number(newBatch.estimatedShelfLifeAmbientDays) || 3.5,
      estimatedShelfLifeColdDays: Number(newBatch.estimatedShelfLifeColdDays) || 14,
      estimatedMarketValueInr: Number(newBatch.estimatedMarketValueInr) || 20000,
      notes: newBatch.notes || '',
      isDemoData: false,
      lastInspectedDate: new Date().toISOString().split('T')[0],
    };

    onAddBatch(created);
    setIsAddModalOpen(false);
  };

  const handleExportCSV = () => {
    const headers = ['Batch Code', 'Crop', 'Variety', 'Harvest Date', 'Quantity (kg)', 'Freshness (%)', 'Grade', 'Risk Level', 'Location', 'Ambient Shelf Days'];
    const rows = batches.map((b) => [
      b.batchCode,
      b.crop,
      `"${b.variety}"`,
      b.harvestDate,
      b.quantityKg,
      b.currentFreshnessScore,
      b.grade,
      b.riskLevel,
      `"${b.location}"`,
      b.estimatedShelfLifeAmbientDays,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `agrorescue-batches-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Fast Action */}
      <div className="liquid-glass rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-extrabold text-stone-900 tracking-tight">
            {t.navBatches}
          </h1>
          <p className="text-xs text-stone-600 mt-0.5">
            Track weight, post-harvest age, storage locations, and prioritize at-risk produce.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-200 rounded-xl transition-colors shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-stone-500" />
            <span>{t.exportData}</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-800 hover:bg-emerald-900 rounded-xl transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4 text-lime-300" />
            <span>{t.addNewBatch}</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="liquid-glass rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t.searchBatches}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-white border border-stone-200 text-stone-900 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2">
          <select
            value={cropFilter}
            onChange={(e) => setCropFilter(e.target.value)}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-white border border-stone-200 text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          >
            <option value="All">{t.filterByCrop}</option>
            <option value="Tomato">Tomato</option>
            <option value="Onion">Onion</option>
            <option value="Potato">Potato</option>
            <option value="Capsicum">Capsicum</option>
          </select>

          <select
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-white border border-stone-200 text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-700"
          >
            <option value="All">{t.filterByRisk}</option>
            <option value="Urgent">Urgent Attention</option>
            <option value="Warning">Warning / Prioritize</option>
            <option value="Stable">Stable</option>
          </select>
        </div>
      </div>

      {/* Batches Table (Desktop) & Cards (Mobile) */}
      <div className="liquid-glass rounded-2xl overflow-hidden">
        {/* Desktop Table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-stone-200/80 bg-stone-50/50 text-stone-500 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">{t.batchCode}</th>
                <th className="py-3 px-4">{t.crop} &amp; {t.variety}</th>
                <th className="py-3 px-4">{t.harvestDate}</th>
                <th className="py-3 px-4 text-right">{t.quantity}</th>
                <th className="py-3 px-4 text-center">{t.freshnessScore}</th>
                <th className="py-3 px-4 text-center">{t.riskLevel}</th>
                <th className="py-3 px-4 text-center">{t.shelfLifeDays}</th>
                <th className="py-3 px-4">{t.storageMethod}</th>
                <th className="py-3 px-4 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredBatches.map((batch) => (
                <tr
                  key={batch.id}
                  className="hover:bg-emerald-50/50 transition-colors group cursor-pointer"
                  onClick={() => setViewingBatch(batch)}
                >
                  <td className="py-3 px-4">
                    <span className="font-mono font-bold text-stone-900 block">
                      {batch.batchCode}
                    </span>
                    {batch.isDemoData && (
                      <span className="text-[10px] text-amber-700 font-medium">Demo Data</span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-bold text-stone-900">{batch.crop}</div>
                    <div className="text-[11px] text-stone-500 truncate max-w-[140px]">
                      {batch.variety}
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-stone-600">
                    {batch.harvestDate}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-stone-900 tabular-nums">
                    {batch.quantityKg.toLocaleString()} kg
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="font-mono font-bold text-stone-900">
                      {batch.currentFreshnessScore}%
                    </span>
                    <span className="text-[10px] text-stone-500 block">{batch.grade}</span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        batch.riskLevel === 'Urgent'
                          ? 'bg-rose-100 text-rose-800'
                          : batch.riskLevel === 'Warning'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {batch.riskLevel}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center font-mono">
                    <span className="font-bold text-stone-900">
                      {batch.estimatedShelfLifeAmbientDays}d
                    </span>
                    <span className="text-[10px] text-stone-500 block">
                      ({batch.estimatedShelfLifeColdDays}d cold)
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-medium text-stone-800">{batch.storageType}</div>
                    <div className="text-[11px] text-stone-500 truncate max-w-[120px]">
                      {batch.location}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => setViewingBatch(batch)}
                        className="p-1.5 text-stone-500 hover:text-emerald-800 hover:bg-emerald-50 rounded-lg transition-colors"
                        title="View details"
                      >
                        <Info className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(t.confirmDelete)) {
                            onDeleteBatch(batch.id);
                          }
                        }}
                        className="p-1.5 text-stone-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Delete batch"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Cards View */}
        <div className="md:hidden divide-y divide-stone-100">
          {filteredBatches.map((batch) => (
            <div
              key={batch.id}
              onClick={() => setViewingBatch(batch)}
              className="p-4 space-y-2 hover:bg-stone-50 active:bg-emerald-50 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="font-mono font-bold text-sm text-stone-900">
                    {batch.batchCode}
                  </span>
                  <div className="text-xs font-semibold text-emerald-900 mt-0.5">
                    {batch.crop} · {batch.variety}
                  </div>
                </div>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    batch.riskLevel === 'Urgent'
                      ? 'bg-rose-100 text-rose-800'
                      : batch.riskLevel === 'Warning'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {batch.riskLevel}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div>
                  <span className="text-stone-500 block text-[11px]">{t.quantity}</span>
                  <span className="font-mono font-bold text-stone-900 tabular-nums">
                    {batch.quantityKg.toLocaleString()} kg
                  </span>
                </div>
                <div>
                  <span className="text-stone-500 block text-[11px]">{t.shelfLifeDays}</span>
                  <span className="font-mono font-bold text-stone-900">
                    {batch.estimatedShelfLifeAmbientDays} {t.daysRemaining}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-stone-500 pt-1 border-t border-stone-100">
                <span>{batch.location}</span>
                <span className="text-emerald-800 font-semibold">Inspect &rarr;</span>
              </div>
            </div>
          ))}
        </div>

        {filteredBatches.length === 0 && (
          <div className="p-8 text-center text-stone-500 text-xs">
            No batches found matching filter criteria.
          </div>
        )}
      </div>

      {/* Add New Batch Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="liquid-glass-elevated rounded-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h2 className="text-base font-bold text-stone-900">{t.addNewBatch}</h2>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewBatch} className="space-y-4 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-800 block mb-1">{t.crop}</label>
                  <select
                    value={newBatch.crop}
                    onChange={(e) => setNewBatch({ ...newBatch, crop: e.target.value as CropType })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-semibold"
                  >
                    <option value="Tomato">Tomato</option>
                    <option value="Onion">Onion</option>
                    <option value="Potato">Potato</option>
                    <option value="Capsicum">Capsicum</option>
                    <option value="Green Chilli">Green Chilli</option>
                    <option value="Banana">Banana</option>
                    <option value="Mango">Mango</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-stone-800 block mb-1">{t.variety}</label>
                  <input
                    type="text"
                    value={newBatch.variety}
                    onChange={(e) => setNewBatch({ ...newBatch, variety: e.target.value })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200"
                    placeholder="e.g. Abhinav Roma"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-800 block mb-1">{t.quantity} (kg)</label>
                  <input
                    type="number"
                    value={newBatch.quantityKg}
                    onChange={(e) => setNewBatch({ ...newBatch, quantityKg: Number(e.target.value) })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-800 block mb-1">{t.harvestDate}</label>
                  <input
                    type="date"
                    value={newBatch.harvestDate}
                    onChange={(e) => setNewBatch({ ...newBatch, harvestDate: e.target.value })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-800 block mb-1">{t.storageMethod}</label>
                  <select
                    value={newBatch.storageType}
                    onChange={(e) => setNewBatch({ ...newBatch, storageType: e.target.value as any })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200"
                  >
                    <option value="Ventilated Crates">Ventilated Crates</option>
                    <option value="Ambient Shed">Ambient Shed</option>
                    <option value="Cold Storage">Cold Storage</option>
                    <option value="On-Field Holding">On-Field Holding</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-stone-800 block mb-1">Storage Location</label>
                  <input
                    type="text"
                    value={newBatch.location}
                    onChange={(e) => setNewBatch({ ...newBatch, location: e.target.value })}
                    className="w-full p-2 rounded-xl bg-white border border-stone-200"
                    placeholder="e.g. Bay 2, Shed C"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-stone-800 block mb-1">Field Observation / Notes</label>
                <textarea
                  value={newBatch.notes}
                  onChange={(e) => setNewBatch({ ...newBatch, notes: e.target.value })}
                  rows={2}
                  className="w-full p-2 rounded-xl bg-white border border-stone-200"
                  placeholder="Notes on harvest condition, transport, handling..."
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-stone-600 hover:text-stone-900 font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-800 hover:bg-emerald-900 text-white font-bold rounded-xl shadow-sm"
                >
                  {t.saveBatch}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Batch Inspection Detail Modal */}
      {viewingBatch && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="liquid-glass-elevated rounded-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div>
                <span className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                  Detailed Batch Record
                </span>
                <h2 className="text-lg font-extrabold text-stone-900 font-mono">
                  {viewingBatch.batchCode}
                </h2>
              </div>
              <button
                onClick={() => {
                  setViewingBatch(null);
                  if (onCloseInspectionModal) onCloseInspectionModal();
                }}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 mt-4 text-xs">
              {viewingBatch.imageUrl && (
                <img
                  src={viewingBatch.imageUrl}
                  alt={viewingBatch.batchCode}
                  className="w-full h-44 object-cover rounded-xl border border-stone-200 shadow-sm"
                />
              )}

              <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-stone-50 border border-stone-200">
                <div>
                  <span className="text-stone-500 block">Crop &amp; Variety</span>
                  <span className="font-bold text-stone-900">{viewingBatch.crop} · {viewingBatch.variety}</span>
                </div>
                <div>
                  <span className="text-stone-500 block">Harvest Date</span>
                  <span className="font-mono font-bold text-stone-900">{viewingBatch.harvestDate}</span>
                </div>
                <div>
                  <span className="text-stone-500 block">Recorded Quantity</span>
                  <span className="font-mono font-bold text-stone-900">{viewingBatch.quantityKg.toLocaleString()} kg</span>
                </div>
                <div>
                  <span className="text-stone-500 block">Est. Market Value</span>
                  <span className="font-mono font-bold text-emerald-800">₹{viewingBatch.estimatedMarketValueInr.toLocaleString()}</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white border border-stone-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-stone-700">Freshness &amp; Quality</span>
                  <span className="font-mono font-bold text-stone-900">{viewingBatch.currentFreshnessScore}% ({viewingBatch.grade})</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-stone-700">Ambient Shelf Life Remaining</span>
                  <span className="font-mono font-bold text-stone-900">{viewingBatch.estimatedShelfLifeAmbientDays} days</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-stone-700">Cold Storage Life (12°C)</span>
                  <span className="font-mono font-bold text-emerald-800">{viewingBatch.estimatedShelfLifeColdDays} days</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-stone-700">Storage Facility</span>
                  <span className="font-medium text-stone-900">{viewingBatch.storageType} ({viewingBatch.location})</span>
                </div>
              </div>

              <div>
                <span className="font-bold text-stone-800 block mb-1">Agronomist &amp; Field Notes</span>
                <p className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-stone-700 leading-relaxed">
                  {viewingBatch.notes}
                </p>
              </div>

              <div className="pt-2 flex items-center justify-end">
                <button
                  onClick={() => {
                    setViewingBatch(null);
                    if (onCloseInspectionModal) onCloseInspectionModal();
                  }}
                  className="px-5 py-2 bg-emerald-800 text-white font-bold rounded-xl"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
